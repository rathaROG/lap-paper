"""Run the unmodified frozen LSAPE harness in three sequential fresh processes."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
EXPERIMENT = ROOT / "experiment"
PYTHON = ROOT.parent / "solver-update-20261029/envs/py311/Scripts/python.exe"


def stamp():
    return datetime.now(timezone.utc).isoformat()


def main():
    status = {"status": "running", "started_utc": stamp(), "sessions": []}
    status_path = ROOT / "campaign-status.json"
    for index in (1, 2, 3):
        command = [str(PYTHON), "-B", "-u", str(EXPERIMENT / "rectangular_campaign.py"),
                   "--manifest", str(EXPERIMENT / "results/rectangular-grid-v1.json"),
                   "--session-index", str(index), "--output", str(ROOT / f"session-{index}")]
        row = {"session_index": index, "status": "running", "started_utc": stamp(),
               "log": f"session-{index}.log"}
        status["sessions"].append(row)
        status_path.write_text(json.dumps(status, indent=2) + "\n")
        print(f"Starting fresh LSAPE session {index}/3", flush=True)
        with (ROOT / row["log"]).open("w", encoding="utf-8") as log:
            result = subprocess.run(command, cwd=EXPERIMENT, stdout=log,
                                    stderr=subprocess.STDOUT, check=False)
        row.update(status="complete" if result.returncode == 0 else "failed",
                   completed_utc=stamp(), returncode=result.returncode)
        status_path.write_text(json.dumps(status, indent=2) + "\n")
        if result.returncode:
            raise SystemExit(result.returncode)
        print(f"Completed fresh LSAPE session {index}/3", flush=True)
    status.update(status="timings_complete", completed_utc=stamp())
    status_path.write_text(json.dumps(status, indent=2) + "\n")
    print("All three measured sessions complete; timing-safe.", flush=True)


if __name__ == "__main__":
    main()
