"""Untimed two-dtype witness for the existing double-precision LSAPE bridge.

This is a bounded regression witness, not an arbitrary-range numerical proof.
It adds no measured arm and does not modify the frozen experiment.
"""
from fractions import Fraction
import hashlib
import importlib
import importlib.metadata as metadata
import json
import math
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "experiment/build"
FUNCTIONS = ("solve", "solve_one_sided", "solve_implicit_scan",
             "solve_specialized", "solve_specialized_padded")


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def enumerate_partial(cost, limit):
    n, m = cost.shape
    half = Fraction.from_float(float(limit) / 2)
    values = []

    def visit(row, used, pairs):
        if row == n:
            selected = sum((Fraction.from_float(float(cost[i, j])) for i, j in pairs), Fraction())
            objective = selected + half * (n + m - 2 * len(pairs))
            values.append((objective, tuple(pairs)))
            return
        visit(row + 1, used, pairs)
        for col in range(m):
            if col not in used:
                visit(row + 1, used | {col}, pairs + [(row, col)])

    visit(0, set(), [])
    optimum = min(value for value, _ in values)
    return values, optimum


def main():
    sys.path.insert(0, str(BUILD))
    native = importlib.import_module("_lsape_native")
    binary = Path(native.__file__).resolve()
    assert binary.parent == BUILD.resolve(), binary
    provenance = json.loads((BUILD / "provenance.json").read_text())
    assert digest(binary) == provenance["output_sha256"]
    limit = float(2**26)
    checks = []
    for dtype in ("float32", "float64"):
        cost = np.array([[2**24, 2**24], [1/8, 1/4]], dtype=dtype)
        before = digest_bytes = hashlib.sha256(cost.tobytes()).hexdigest()
        states, expected = enumerate_partial(cost, limit)
        assert len(states) == 7 and expected == Fraction(2**24) + Fraction(1, 8)
        for name in FUNCTIONS:
            pairs = np.asarray(getattr(native, name)(cost, limit))
            assert pairs.shape == (2, 2) and pairs.dtype == np.int64
            assert {tuple(map(int, row)) for row in pairs} == {(0, 1), (1, 0)}
            selected = [float(cost[i, j]) for i, j in pairs]
            exact = sum(map(Fraction.from_float, selected), Fraction())
            exact += Fraction.from_float(limit / 2) * (sum(cost.shape) - 2 * len(pairs))
            restored = math.fsum(selected) + (limit / 2) * (sum(cost.shape) - 2 * len(pairs))
            assert exact == expected and restored == float(expected)
            assert hashlib.sha256(cost.tobytes()).hexdigest() == before
            checks.append({"input_dtype": dtype, "entry_point": name,
                           "pairs": pairs.tolist(), "original_endpoint_objective": restored,
                           "exact_numerator": exact.numerator, "exact_denominator": exact.denominator,
                           "enumerated_states": len(states), "input_unchanged": True,
                           "input_sha256": digest_bytes})
    result = {"status": "passed", "scope": __doc__.strip(),
              "timing_measurement": False, "measured_experiment_modified": False,
              "python": sys.version,
              "versions": {key: metadata.version(key) for key in ("numpy", "scipy")},
              "source_sha256": provenance["input_sha256"],
              "witness_script_sha256": digest(__file__), "binary_sha256": digest(binary),
              "input": [[2**24, 2**24], [1/8, 1/4]], "limit": limit,
              "objective": "math.fsum(selected represented costs) + (L/2)*(n+m-2*K)",
              "reference": "Exhaustive partial matchings, exact Fraction arithmetic on represented inputs",
              "expected_objective": float(Fraction(2**24) + Fraction(1, 8)),
              "checks": checks,
              "interpretation": "All five existing LSAPE arms convert either input dtype through the double bridge"
                                " and preserve this exactly represented 1/8 difference. This supports the"
                                " absence of a required mechanical float32-workspace port for this example;"
                                " it is not a proof for all magnitudes, near ties, or arithmetic paths."}
    (ROOT / "precision-port-check.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "checks": len(checks),
                      "expected_objective": result["expected_objective"]}))


if __name__ == "__main__":
    main()
