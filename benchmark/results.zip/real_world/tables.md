| Method | Replay float32 | Replay float64 | Centroid update | SORT update |
| --- | --- | --- | --- | --- |
| lapjv | 0.758–1.856 | 0.715–1.829 | 0.919–1.057 | 0.985–1.009 |
| lapjvx | 0.784–1.852 | 0.762–1.861 | 0.959–1.040 | 0.978–1.008 |
| lapjvxa | 0.856–1.955 | 0.845–1.943 | 0.929–1.071 | 0.992–1.010 |
| lapjvh | 1.387–3.155 | 1.309–2.825 | 1.010–1.114 | 0.995–1.012 |
| laprust | 1.427–3.138 | 1.327–2.798 | 1.045–1.111 | 0.995–1.022 |
| lapcpp | 1.233–2.917 | 1.173–2.642 | 1.016–1.107 | 0.992–1.007 |
| scipy | 1.000–1.000 | 1.000–1.000 | 1.000–1.000 | 1.000–1.000 |
| lapjvs | 0.784–2.028 | 0.745–1.898 | 0.924–1.069 | 0.985–1.018 |
| lapjvc | 0.774–0.995 | 0.701–0.900 | 0.981–1.019 | 0.987–0.997 |

**Table 12.** Real-sequence speedup ranges relative to SciPy, computed within each pipeline and originating session. Values are minima–maxima across pipelines of SciPy's nine-round median time divided by the method's nine-round median time; replay covers eight pipelines per precision, and tracker updates cover four per tracker. Ranges are descriptive extrema, not interquartile ranges.

| Pipeline | GT boxes | Det. boxes | Det./frame | LAP calls | Rows min–max | Cols min–max | Square % |
| --- | --- | --- | --- | --- | --- | --- | --- |
| MOT16-04 / GT / Centroid | 51545 | 51545 | 51.60 | 998 | 47–56 | 47–56 | 94.0 |
| MOT16-04 / GT / SORT | 51545 | 51545 | 51.60 | 998 | 47–56 | 47–56 | 91.7 |
| MOT16-04 / RF768 / Centroid | 51545 | 30621 | 30.65 | 998 | 22–39 | 23–39 | 18.6 |
| MOT16-04 / RF768 / SORT | 51545 | 30621 | 30.65 | 976 | 23–39 | 24–42 | 7.2 |
| MOT20-03 / GT / Centroid | 106637 | 106637 | 106.74 | 998 | 84–134 | 84–134 | 74.9 |
| MOT20-03 / GT / SORT | 106637 | 106637 | 106.74 | 998 | 84–134 | 84–134 | 66.1 |
| MOT20-03 / RF768 / Centroid | 106637 | 45990 | 46.04 | 998 | 34–62 | 34–62 | 14.6 |
| MOT20-03 / RF768 / SORT | 106637 | 45990 | 46.04 | 575 | 36–62 | 39–66 | 8.5 |

**Table C1.** Real-sequence workload over 999 decoded frames per clip. GT and detector box totals count observations, not unique people. LAP dimensions and square percentages describe actual SciPy-captured assignment calls; SORT fast paths are retained. RF768 denotes Nano at 768 pixels and confidence 0.2, with person class 1, max_det 300 and minimum box width 15 pixels.

| Pipeline | scipy | lapjvh | laprust | lapcpp |
| --- | --- | --- | --- | --- |
| MOT16-04 / GT / Centroid | 0.129 [0.125, 0.131] | 0.119 [0.119, 0.120] | 0.116 [0.115, 0.117] | 0.116 [0.115, 0.120] |
| MOT16-04 / GT / SORT | 1.549 [1.530, 1.560] | 1.546 [1.538, 1.569] | 1.557 [1.548, 1.571] | 1.549 [1.531, 1.549] |
| MOT16-04 / RF768 / Centroid | 0.079 [0.075, 0.082] | 0.071 [0.069, 0.073] | 0.073 [0.069, 0.073] | 0.073 [0.071, 0.075] |
| MOT16-04 / RF768 / SORT | 1.022 [1.011, 1.058] | 1.022 [1.016, 1.052] | 1.010 [1.005, 1.037] | 1.016 [1.006, 1.031] |
| MOT20-03 / GT / Centroid | 0.324 [0.323, 0.330] | 0.295 [0.292, 0.298] | 0.292 [0.290, 0.294] | 0.294 [0.291, 0.300] |
| MOT20-03 / GT / SORT | 3.176 [3.139, 3.180] | 3.140 [3.111, 3.159] | 3.109 [3.092, 3.138] | 3.153 [3.135, 3.211] |
| MOT20-03 / RF768 / Centroid | 0.111 [0.110, 0.111] | 0.110 [0.105, 0.110] | 0.106 [0.105, 0.107] | 0.109 [0.105, 0.113] |
| MOT20-03 / RF768 / SORT | 1.471 [1.446, 1.496] | 1.478 [1.462, 1.504] | 1.474 [1.455, 1.495] | 1.483 [1.450, 1.500] |

**Table C2.** Tracker update time in milliseconds per frame: median [Q1, Q3] across nine whole-clip means. Fresh Persons, decoding, detector inference, result copying and evaluation are excluded. The frozen artifact includes all nine methods; these absolute times show SciPy and the three native implementations.

| Pipeline / precision | scipy | lapjvh | laprust | lapcpp |
| --- | --- | --- | --- | --- |
| MOT16-04 / GT / Centroid / float32 | 14.78 [14.64, 14.97] | 5.57 [5.55, 5.68] | 5.77 [5.76, 5.85] | 6.25 [6.22, 6.45] |
| MOT16-04 / GT / Centroid / float64 | 14.41 [14.25, 14.76] | 6.02 [5.99, 6.48] | 6.13 [6.06, 6.41] | 6.52 [6.48, 6.72] |
| MOT16-04 / GT / SORT / float32 | 14.84 [14.67, 16.55] | 6.02 [5.85, 6.12] | 5.90 [5.81, 6.91] | 6.33 [6.27, 6.75] |
| MOT16-04 / GT / SORT / float64 | 14.46 [14.39, 14.87] | 6.31 [6.29, 6.59] | 6.33 [6.20, 6.52] | 6.58 [6.49, 6.81] |
| MOT16-04 / RF768 / Centroid / float32 | 8.97 [8.82, 9.01] | 5.02 [4.96, 5.06] | 5.00 [4.97, 5.09] | 5.21 [5.18, 5.23] |
| MOT16-04 / RF768 / Centroid / float64 | 8.75 [8.69, 8.99] | 5.14 [5.13, 5.16] | 5.20 [5.12, 5.31] | 5.39 [5.37, 5.47] |
| MOT16-04 / RF768 / SORT / float32 | 9.91 [9.72, 10.04] | 4.07 [4.06, 4.14] | 4.09 [4.09, 4.11] | 4.16 [4.15, 4.20] |
| MOT16-04 / RF768 / SORT / float64 | 9.49 [9.41, 9.55] | 4.25 [4.23, 4.29] | 4.27 [4.21, 4.28] | 4.36 [4.30, 4.41] |
| MOT20-03 / GT / Centroid / float32 | 46.99 [46.79, 50.21] | 17.15 [16.75, 18.25] | 16.81 [16.72, 18.18] | 19.01 [18.60, 20.15] |
| MOT20-03 / GT / Centroid / float64 | 45.83 [45.42, 46.16] | 18.32 [18.22, 18.60] | 18.31 [18.27, 19.67] | 20.23 [20.07, 21.51] |
| MOT20-03 / GT / SORT / float32 | 47.98 [47.70, 50.79] | 15.21 [15.15, 15.51] | 15.29 [15.20, 15.50] | 16.45 [16.30, 17.03] |
| MOT20-03 / GT / SORT / float64 | 47.02 [46.33, 47.75] | 16.64 [16.57, 17.04] | 16.80 [16.73, 17.51] | 17.80 [17.73, 18.29] |
| MOT20-03 / RF768 / Centroid / float32 | 14.68 [14.42, 15.01] | 10.59 [10.36, 10.69] | 10.29 [10.15, 10.88] | 11.90 [11.39, 12.03] |
| MOT20-03 / RF768 / Centroid / float64 | 14.01 [13.98, 14.04] | 10.70 [10.49, 10.77] | 10.56 [10.48, 10.63] | 11.94 [11.80, 12.02] |
| MOT20-03 / RF768 / SORT / float32 | 15.50 [15.32, 15.63] | 5.41 [5.32, 5.45] | 5.40 [5.37, 5.46] | 5.59 [5.58, 5.62] |
| MOT20-03 / RF768 / SORT / float64 | 14.69 [14.59, 14.99] | 5.76 [5.66, 5.78] | 5.73 [5.61, 5.77] | 5.91 [5.70, 6.14] |

**Table C3.** Common-cost replay time in microseconds per assignment: median [Q1, Q3] over nine corpus means. Every method receives the same captured pipeline corpus. The float64 view widens the captured float32 costs; cost construction is unchanged. Adapter conversion, finite checks and pair normalization remain inside replay timing.

| Pipeline | IDF1 % min–max | MOTA % min–max | IDSW min–max | FP min–max | FN min–max |
| --- | --- | --- | --- | --- | --- |
| MOT16-04 / GT / Centroid | 99.48–100.00 | 100.00–100.00 | 0–1 | 0–0 | 0–0 |
| MOT16-04 / GT / SORT | 99.12–99.12 | 99.78–99.78 | 0–0 | 0–0 | 115–115 |
| MOT16-04 / RF768 / Centroid | 28.07–28.44 | 40.40–40.42 | 1568–1579 | 4108–4109 | 25032–25033 |
| MOT16-04 / RF768 / SORT | 34.99–34.99 | 40.60–40.60 | 535–535 | 2273–2273 | 27811–27811 |
| MOT20-03 / GT / Centroid | 100.00–100.00 | 100.00–100.00 | 0–0 | 0–0 | 0–0 |
| MOT20-03 / GT / SORT | 99.76–99.76 | 99.51–99.51 | 0–0 | 0–0 | 518–518 |
| MOT20-03 / RF768 / Centroid | 28.50–28.90 | 38.13–38.13 | 2990–2993 | 1168–1168 | 61815–61815 |
| MOT20-03 / RF768 / SORT | 36.75–36.75 | 35.58–35.58 | 729–729 | 619–619 | 67348–67348 |

**Table C4.** Supplied-box accuracy ranges across all nine assignment methods. IDF1 and MOTA are percentages; IDSW, FP and FN are counts. Evaluation uses motmetrics 1.4.0 and IoU at least 0.5 outside all timing. Converted annotations lack official MOTChallenge class/ignore metadata, so these are not leaderboard scores. Equal-cost assignment choices can propagate to different identities; no method-independent tracking-accuracy gain is claimed.
