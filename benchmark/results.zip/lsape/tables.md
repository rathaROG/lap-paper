| Shape / series | $O$ (ms) | $P$ unmatched (%) | $O/U$ | $U/P$ | $O/P$ | $P/T$ |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 1024 × 1024, F | 19.796 | 0.00 | 0.42 [0.41, 0.43] | 1.13 [1.11, 1.13] | 0.47 [0.47, 0.48] | 0.73 [0.70, 0.74] |
| 512 × 640, F | 8.510 | 0.00 | 2.16 [2.15, 2.18] | 1.11 [1.11, 1.12] | 2.41 [2.39, 2.43] | 0.85 [0.85, 0.85] |
| 640 × 512, F | 8.001 | 0.00 | 0.55 [0.55, 0.59] | 1.18 [1.17, 1.18] | 0.66 [0.66, 0.69] | 0.96 [0.93, 0.97] |
| Blocks 1024 × 1280, F | 36.319 | 43.75 | 1.02 [0.99, 1.08] | 1.12 [1.12, 1.14] | 1.15 [1.13, 1.20] | 0.78 [0.75, 0.78] |
| Blocks 1280 × 1024, F | 37.731 | 43.75 | 1.38 [1.37, 1.42] | 1.11 [1.11, 1.12] | 1.53 [1.53, 1.58] | 0.91 [0.90, 0.91] |
| 256 × 1024, F | 3.835 | 0.00 | 2.26 [2.21, 2.29] | 1.09 [1.06, 1.11] | 2.46 [2.39, 2.49] | 0.98 [0.98, 1.01] |
| 1024 × 256, F | 4.463 | 0.00 | 0.94 [0.93, 0.96] | 1.16 [1.14, 1.17] | 1.09 [1.06, 1.12] | 0.96 [0.94, 0.97] |
| 64 × 16384, F | 7.973 | 0.00 | 1.26 [1.24, 1.27] | 1.05 [1.02, 1.06] | 1.32 [1.29, 1.33] | 0.87 [0.85, 0.88] |
| 16384 × 64, F | 8.658 | 0.00 | 0.97 [0.95, 0.99] | 1.15 [1.15, 1.20] | 1.13 [1.12, 1.15] | 0.77 [0.76, 0.80] |
| 64 × 16384, S | 6.250 | 11.33 | 0.96 [0.92, 0.98] | 1.03 [1.03, 1.07] | 0.99 [0.99, 1.01] | 0.89 [0.84, 0.91] |
| 16384 × 64, S | 6.521 | 11.33 | 0.96 [0.95, 0.98] | 1.15 [1.12, 1.17] | 1.10 [1.10, 1.11] | 0.82 [0.81, 0.84] |
| Ties 256 × 320, Q | 0.352 | 27.64 | 0.91 [0.90, 0.96] | 1.16 [1.13, 1.19] | 1.07 [1.06, 1.09] | 1.00 [0.99, 1.02] |

**Table 10.** Controlled LSAPE comparison: original $O$, unchanged one-sided $U$, specialized padded $P$, and compact tracked $T$. $O/U$ measures formulation, $U/P$ combined specialization, $O/P$ total, and $P/T$ layout; ratios above one favor the denominator. Ratios are medians of three paired-log estimates [process minimum, maximum], not confidence intervals. $O$ milliseconds are medians of session medians; $P$ unmatched percentages are medians of session means on the smaller side. Ties can give $O$ a different cardinality. F: $L=0.5$; S: $L=2/\max(n,m)$; Q: $h=2^{-\lceil\log_2\max(n,m)\rceil}$, $L=2h$, $C=h\lfloor X/h\rfloor$, $X\sim U[0,1)$. These 12 rows were preselected from 67 cases; all observations are retained. Separately summarized ratio medians need not multiply exactly.

| Case block | Cases | Gains for P | Regressions for P | Within band |
| --- | ---: | ---: | ---: | ---: |
| A: squares | 8 | 0 | 7 | 1 |
| B: uniform 5:4 rectangles | 16 | 4 | 9 | 3 |
| C: congested 5:4 rectangles | 8 | 8 | 0 | 0 |
| D: uniform 4:1 rectangles | 16 | 14 | 0 | 2 |
| E: extreme rectangles | 12 | 10 | 0 | 2 |
| F: threshold ties | 7 | 3 | 0 | 4 |
| All cases | 67 | 39 | 16 | 12 |

**Table 11.** Original versus specialized padded LSAPE ($O/P$), using the median of three process estimates. Gains exceed 1.03, regressions are below 0.97, and central estimates in [0.97, 1.03] lie within the declared practical band. Counts are descriptive, not significance tests or evidence of equivalence.
