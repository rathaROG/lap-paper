Saved measurements for the paper. See benchmark/RESULTS.md in the repository.
