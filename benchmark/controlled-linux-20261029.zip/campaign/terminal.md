Yes—use your existing Conda environments. Your original commands work once the correct environment is active.

In the **Python 3.11.18** environment:

```bash
python -m pip install -r benchmark/requirements-py311.txt
python benchmark/run_all.py --output benchmark/runs/full-linux-p311-20261029 --cpu 0 --batch-cpus 0 2 4 6
```

Then activate the **Python 3.14.10** environment:

```bash
python -m pip install -r benchmark/requirements-py314.txt
python benchmark/run_all.py --output benchmark/runs/full-linux-p314-20261029 --cpu 0 --batch-cpus 0 2 4 6
```

Run sequentially, using the same CPU selection as the previous Linux benchmarks. After both finish:

```bash
python benchmark/audit_controlled_update.py \
  benchmark/runs/full-linux-p311-20261029 \
  benchmark/runs/full-linux-p314-20261029 \
  --output benchmark/runs/linux-audit-20261029.json
```

------------------------------------------------------------


(l31118) ratha@home:/media/ratha/HOT/DEV/projects/lapx_all/new8/lap-paper$ python benchmark/run_all.py --output benchmark/runs/full-linux-p311-20261029 --cpu 0 --batch-cpus 0 2 4 6
== base: run.py --output <output>/base --cpu 0 --batch-cpus 0 2 4 6
Validation 16800 calls passed
Single square128
Single square512
Single wide64x512
Single tall512x64
Single near256x320
Single blocks256x320
Single ties128x160
Single optional128x160
Single optional256x320
Single tight128x160
Single negative128x160
Single optional_square128
Batch batch64x64x80
Batch batch16x128x160_optional
Batch batch1024x8x10
Memory required jvrust
Memory required jvhybrid
Memory required jvcpp
Memory required jvx
Memory required scipy
Memory optional jvrust
Memory optional jvhybrid
Memory optional jvcpp
Memory optional jvx
Memory optional scipy

Table 4: median microseconds per matrix
case                    JVRUST  JVHYBRID     JVCPP       JVX       JVS       JVC     SciPy
square128                 70.5      69.3      69.3     131.2     127.2     238.8     262.2
square512               1093.5    1098.1    1142.6    4003.3    3983.8    5353.6    4962.3
wide64x512                15.8      14.8      14.9     450.3     406.2     972.4      71.8
tall512x64                29.8      27.2      77.3     469.1     422.4    1226.2     140.9
near256x320               91.5      84.6      85.0     173.0     174.4    3823.4     543.7
blocks256x320            894.8     889.4     926.9   11687.8   11682.6    5246.2    1401.2
ties128x160               13.2      12.9      14.2      55.5      54.9      79.3      74.6
optional128x160           13.6      13.6      17.3     431.4     425.6    1949.8     428.1
optional256x320           69.1      68.6      71.2    2631.5    2585.4   13467.6    1741.1
tight128x160               9.0       9.0      13.3     372.2     359.5    2262.7    1054.4
negative128x160           14.1      14.1      17.9     864.1     862.7    2698.9     425.0
optional_square128        75.2      75.5      79.6     206.8     207.0     460.4     499.2

Table 5: median milliseconds per complete batch
  batch64x64x80: jvcpp_batch_t1 0.773, jvcpp_batch_t4 0.281, jvhybrid_batch_t1 0.746, jvhybrid_batch_t4 0.213, jvrust_batch_t1 0.771, jvrust_batch_t4 0.225, jvrust_loop 0.870, jvx_batch_t1 1.573, jvx_batch_t4 1.616, scipy_loop 2.585
  batch16x128x160_optional: jvcpp_batch_t1 0.417, jvcpp_batch_t4 0.168, jvhybrid_batch_t1 0.398, jvhybrid_batch_t4 0.121, jvrust_batch_t1 0.407, jvrust_batch_t4 0.124, jvrust_loop 0.398, jvx_batch_t1 7.599, jvx_batch_t4 2.462, scipy_loop 7.651
  batch1024x8x10: jvcpp_batch_t1 0.544, jvcpp_batch_t4 0.238, jvhybrid_batch_t1 0.553, jvhybrid_batch_t4 0.201, jvrust_batch_t1 0.537, jvrust_batch_t4 0.197, jvrust_loop 1.017, jvx_batch_t1 5.015, jvx_batch_t4 11.875, scipy_loop 2.200

Table 6: additional peak for 256 x 4096 (MiB)
  required  JVRUST         0.00
  required  JVHYBRID       0.00
  required  JVCPP          0.00
  required  JVX          116.42
  required  SciPy          0.00
  optional  JVRUST         0.00
  optional  JVHYBRID       0.00
  optional  JVCPP          0.00
  optional  JVX          132.80
  optional  SciPy        132.74

Results saved: <benchmark>/runs/full-linux-p311-20261029/base
== formulations: run.py --output <output>/formulations --cpu 0
Independent optional validation passed: 10500
optional128x160 mean pairs 128.0
optional256x320 mean pairs 256.0
tight128x160 mean pairs 119.75
negative128x160 mean pairs 128.0
optional_square128 mean pairs 128.0
reject128x160_L005 mean pairs 40.25
reject128x160_L001 mean pairs 11.0
reject_tall160x128 mean pairs 38.5
optional_wide64x512 mean pairs 46.0
optional_blocks256x320 mean pairs 144.0

Table 7: median microseconds per matrix; Unmatched = mean smaller-side unmatched rows
case                               JVRUST            JVCPP     SciPy square SciPy dummy cols     SciPy capped  Unmatched
optional128x160                      13.6             17.3            428.8            248.5            124.2       0.00
optional256x320                      69.1             71.3           1765.1           1061.4            532.1       0.00
tight128x160                          9.0             13.2           1053.4            244.4            103.3       8.25
negative128x160                      14.2             17.9            424.6            233.9            133.4       0.00
optional_square128                   75.3             79.7            499.8            393.2            212.7       0.00
reject128x160_L005                    5.6              6.4            820.2            164.1             69.6      87.75
reject128x160_L001                    5.3              6.0            501.4            157.7             64.2     117.00
reject_tall160x128                   13.6             12.1            847.1            168.0             76.6      89.50
optional_wide64x512                   8.2              8.3           1566.0            191.2             82.5      18.00
optional_blocks256x320              681.4            705.0           2069.4           1372.3            719.8     112.00

Results saved: <benchmark>/runs/full-linux-p311-20261029/formulations
== scaling: run.py --output <output>/scaling --cpu 0
1/47 required_square_16x16 unmatched=0.00 elapsed=0.8s
2/47 required_square_32x32 unmatched=0.00 elapsed=1.7s
3/47 required_square_64x64 unmatched=0.00 elapsed=3.3s
4/47 required_square_128x128 unmatched=0.00 elapsed=5.2s
5/47 required_square_256x256 unmatched=0.00 elapsed=7.1s
6/47 required_square_512x512 unmatched=0.00 elapsed=9.2s
7/47 required_square_1024x1024 unmatched=0.00 elapsed=13.4s
8/47 required_wide_16x64 unmatched=0.00 elapsed=14.6s
9/47 required_wide_32x128 unmatched=0.00 elapsed=16.0s
10/47 required_wide_64x256 unmatched=0.00 elapsed=17.6s
11/47 required_wide_128x512 unmatched=0.00 elapsed=19.5s
12/47 required_wide_256x1024 unmatched=0.00 elapsed=22.0s
13/47 required_wide_512x2048 unmatched=0.00 elapsed=31.9s
14/47 required_fixed_64x64 unmatched=0.00 elapsed=33.5s
15/47 required_fixed_64x128 unmatched=0.00 elapsed=35.2s
16/47 required_fixed_64x256 unmatched=0.00 elapsed=36.8s
17/47 required_fixed_64x512 unmatched=0.00 elapsed=38.6s
18/47 required_fixed_64x1024 unmatched=0.00 elapsed=40.5s
19/47 required_fixed_64x2048 unmatched=0.00 elapsed=43.2s
20/47 required_fixed_64x4096 unmatched=0.00 elapsed=52.1s
21/47 optional_square_16x16 unmatched=0.00 elapsed=53.0s
22/47 optional_square_32x32 unmatched=0.00 elapsed=54.1s
23/47 optional_square_64x64 unmatched=0.00 elapsed=55.5s
24/47 optional_square_128x128 unmatched=0.00 elapsed=57.2s
25/47 optional_square_256x256 unmatched=0.00 elapsed=58.9s
26/47 optional_square_512x512 unmatched=0.00 elapsed=61.0s
27/47 optional_square_1024x1024 unmatched=0.00 elapsed=68.5s
28/47 optional_wide_16x64 unmatched=0.00 elapsed=69.8s
29/47 optional_wide_32x128 unmatched=0.00 elapsed=71.1s
30/47 optional_wide_64x256 unmatched=0.00 elapsed=72.5s
31/47 optional_wide_128x512 unmatched=0.00 elapsed=74.4s
32/47 optional_wide_256x1024 unmatched=0.00 elapsed=81.0s
33/47 optional_wide_512x2048 unmatched=0.00 elapsed=125.3s
34/47 optional_fixed_64x64 unmatched=0.00 elapsed=126.9s
35/47 optional_fixed_64x128 unmatched=0.00 elapsed=128.2s
36/47 optional_fixed_64x256 unmatched=0.00 elapsed=129.7s
37/47 optional_fixed_64x512 unmatched=0.00 elapsed=131.5s
38/47 optional_fixed_64x1024 unmatched=0.00 elapsed=137.2s
39/47 optional_fixed_64x2048 unmatched=0.00 elapsed=174.2s
40/47 optional_fixed_64x4096 unmatched=0.00 elapsed=537.3s
41/47 optional_blocks_16x20 unmatched=7.00 elapsed=538.5s
42/47 optional_blocks_32x40 unmatched=14.00 elapsed=539.8s
43/47 optional_blocks_64x80 unmatched=28.00 elapsed=541.5s
44/47 optional_blocks_128x160 unmatched=56.00 elapsed=543.3s
45/47 optional_blocks_256x320 unmatched=112.00 elapsed=545.2s
46/47 optional_blocks_512x640 unmatched=224.00 elapsed=550.3s
47/47 optional_blocks_1024x1280 unmatched=448.00 elapsed=581.0s

Median microseconds per matrix (Figures 6-8)

optional blocks
shape                  JVRUST            JVCPP              JVX     SciPy square SciPy dummy cols     SciPy capped
16x20                    0.9              0.9              9.2              9.3              4.9              4.2
32x40                    2.2              2.5             38.6             31.6             18.5             11.9
64x80                   30.6             35.4            227.3            121.9             75.3             42.0
128x160                 177.1            183.7           1316.9            530.7            353.1            189.0
256x320                 701.2            729.7           8753.7           2214.2           1520.4            774.3
512x640                2857.2           2955.0          73725.6           9291.3           6631.2           3419.3
1024x1280              11243.6          11606.4         572045.6          45328.4          32288.6          16371.7

optional fixed
shape                  JVRUST            JVCPP              JVX     SciPy square SciPy dummy cols     SciPy capped
64x64                   20.3             22.4             56.0            108.8             79.6             51.3
64x128                   3.2              4.8            330.4            140.5             47.5             35.9
64x256                   4.8              7.2           1895.8            327.2             59.7             50.6
64x512                   9.1             10.7          12292.7            981.8             86.8             79.7
64x1024                 16.6             17.6          99849.0           3398.7            151.6            145.5
64x2048                 31.0             30.8         798912.0          14698.0            300.0            293.5
64x4096                 60.2             57.4        8165365.8          57650.9            579.2            574.0

optional square
shape                  JVRUST            JVCPP              JVX     SciPy square SciPy dummy cols     SciPy capped
16x16                    1.0              1.0              6.5              9.1              4.9              3.9
32x32                    2.6              2.7             16.5             29.9             18.2             10.2
64x64                   14.3             16.6             56.1            108.1             78.7             50.9
128x128                  91.5             96.8            313.2            486.3            379.3            241.1
256x256                 410.7            417.2           1290.2           2145.8           1734.3           1057.6
512x512                2018.2           2043.7           6040.4           9900.3           8306.7           4753.4
1024x1024              11038.6          11122.4          25464.2          50417.3          42097.6          23179.5

optional wide
shape                  JVRUST            JVCPP              JVX     SciPy square SciPy dummy cols     SciPy capped
16x64                    0.9              1.0             53.9             26.1              6.2              5.6
32x128                   1.7              1.9            305.2             88.9             17.8             14.2
64x256                   4.7              6.9           1882.7            323.4             56.3             47.6
128x512                  22.7             24.3          13976.2           1262.3            222.0            185.2
256x1024                 86.0             83.8         118105.1           5035.5            917.4            751.6
512x2048                372.8            355.3         952806.4          23401.1           3787.5           3207.6

required fixed
shape                  JVRUST         JVHYBRID            JVCPP              JVX              JVS              JVC            SciPy
64x64                   16.0             15.5             15.4             20.6             17.0             43.5             50.0
64x128                   8.5              8.0              8.1             32.1             35.5            224.2             32.4
64x256                  10.9             10.3             10.4            112.7            108.0            524.1             45.6
64x512                  16.1             14.9             15.1            455.6            407.8           1198.9             76.3
64x1024                 26.0             23.9             24.1           1850.5           1620.6           3388.0            136.4
64x2048                 45.7             41.5             41.6          11259.5          10069.8          16649.0            266.5
64x4096                 85.8             78.1             77.7          49311.0          43578.2          83112.5            521.7

required square
shape                  JVRUST         JVHYBRID            JVCPP              JVX              JVS              JVC            SciPy
16x16                    1.1              1.0              1.0              3.8              1.5              4.1              2.3
32x32                    2.3              2.1              2.0              5.2              2.8              7.9              8.5
64x64                   15.7             15.3             15.6             23.5             19.5             49.4             49.5
128x128                  74.1             72.5             72.4            167.0            164.2            264.0            245.2
256x256                 220.3            218.8            224.6            368.1            364.4            985.2           1053.1
512x512                1038.8           1037.4           1084.8           3467.8           3451.9           5383.6           4786.1
1024x1024               4260.2           4300.6           4453.1          13356.6          13255.6          20409.7          23086.4

required wide
shape                  JVRUST         JVHYBRID            JVCPP              JVX              JVS              JVC            SciPy
16x64                    1.0              0.9              0.9             11.6             14.0             17.0              3.8
32x128                   3.1              2.6              2.9             33.0             34.6             96.1             11.8
64x256                  10.5              9.9             10.1            112.8            108.3            400.5             43.2
128x512                  36.6             33.7             33.7            426.1            399.4           3958.4            200.3
256x1024                116.8            107.1            107.5           1648.0           1505.2          21643.5            703.4
512x2048                464.7            431.5            432.9           9135.1           8521.5         180492.3           2975.8

Results saved: <benchmark>/runs/full-linux-p311-20261029/scaling
== extended: run.py --output <output>/extended --cpu 0
Plan: 132 timing cases, 405 fresh-process memory trials
Timing 1/132: 000_large_square_required_1000x1000
Timing 2/132: 001_large_square_optional_1000x1000
Timing 3/132: 002_large_square_required_2000x2000
Timing 4/132: 003_large_square_optional_2000x2000
Timing 5/132: 004_large_square_required_3000x3000
Timing 6/132: 005_large_square_optional_3000x3000
Timing 7/132: 006_large_square_required_5000x5000
Timing 8/132: 007_large_square_optional_5000x5000
Timing 9/132: 008_large_rectangle_required_1000x2000
Timing 10/132: 009_large_rectangle_optional_1000x2000
Timing 11/132: 010_large_rectangle_required_2000x1000
Timing 12/132: 011_large_rectangle_optional_2000x1000
Timing 13/132: 012_large_rectangle_required_2000x3000
Timing 14/132: 013_large_rectangle_optional_2000x3000
Timing 15/132: 014_large_rectangle_required_3000x2000
Timing 16/132: 015_large_rectangle_optional_3000x2000
Timing 17/132: 016_large_rectangle_required_4000x5000
Timing 18/132: 017_large_rectangle_optional_4000x5000
Timing 19/132: 018_large_rectangle_required_5000x4000
Timing 20/132: 019_large_rectangle_optional_5000x4000
Timing 21/132: 020_extreme_rectangle_required_64x4096
Timing 22/132: 021_extreme_rectangle_optional_64x4096
Timing 23/132: 022_extreme_rectangle_required_4096x64
Timing 24/132: 023_extreme_rectangle_optional_4096x64
Timing 25/132: 024_extreme_rectangle_required_64x8192
Timing 26/132: 025_extreme_rectangle_optional_64x8192
Timing 27/132: 026_extreme_rectangle_required_8192x64
Timing 28/132: 027_extreme_rectangle_optional_8192x64
Timing 29/132: 028_extreme_rectangle_required_64x16384
Timing 30/132: 029_extreme_rectangle_optional_64x16384
Timing 31/132: 030_extreme_rectangle_required_16384x64
Timing 32/132: 031_extreme_rectangle_optional_16384x64
Timing 33/132: 032_congestion_required_256x320
Timing 34/132: 033_congestion_optional_256x320
Timing 35/132: 034_congestion_required_256x320
Timing 36/132: 035_congestion_optional_256x320
Timing 37/132: 036_congestion_required_256x320
Timing 38/132: 037_congestion_optional_256x320
Timing 39/132: 038_congestion_required_256x320
Timing 40/132: 039_congestion_optional_256x320
Timing 41/132: 040_congestion_required_256x320
Timing 42/132: 041_congestion_optional_256x320
Timing 43/132: 042_forbidden_required_256x320
Timing 44/132: 043_forbidden_optional_256x320
Timing 45/132: 044_forbidden_required_256x320
Timing 46/132: 045_forbidden_optional_256x320
Timing 47/132: 046_forbidden_required_256x320
Timing 48/132: 047_forbidden_optional_256x320
Timing 49/132: 048_forbidden_required_256x320
Timing 50/132: 049_forbidden_optional_256x320
Timing 51/132: 050_ties_required_256x320
Timing 52/132: 051_ties_optional_256x320
Timing 53/132: 052_ties_required_256x320
Timing 54/132: 053_ties_optional_256x320
Timing 55/132: 054_ties_required_256x320
Timing 56/132: 055_ties_optional_256x320
Timing 57/132: 056_ties_required_256x320
Timing 58/132: 057_ties_optional_256x320
Timing 59/132: 058_congestion_required_512x640
Timing 60/132: 059_congestion_optional_512x640
Timing 61/132: 060_congestion_required_512x640
Timing 62/132: 061_congestion_optional_512x640
Timing 63/132: 062_congestion_required_512x640
Timing 64/132: 063_congestion_optional_512x640
Timing 65/132: 064_congestion_required_512x640
Timing 66/132: 065_congestion_optional_512x640
Timing 67/132: 066_congestion_required_512x640
Timing 68/132: 067_congestion_optional_512x640
Timing 69/132: 068_forbidden_required_512x640
Timing 70/132: 069_forbidden_optional_512x640
Timing 71/132: 070_forbidden_required_512x640
Timing 72/132: 071_forbidden_optional_512x640
Timing 73/132: 072_forbidden_required_512x640
Timing 74/132: 073_forbidden_optional_512x640
Timing 75/132: 074_forbidden_required_512x640
Timing 76/132: 075_forbidden_optional_512x640
Timing 77/132: 076_ties_required_512x640
Timing 78/132: 077_ties_optional_512x640
Timing 79/132: 078_ties_required_512x640
Timing 80/132: 079_ties_optional_512x640
Timing 81/132: 080_ties_required_512x640
Timing 82/132: 081_ties_optional_512x640
Timing 83/132: 082_ties_required_512x640
Timing 84/132: 083_ties_optional_512x640
Timing 85/132: 084_signed_required_256x320
Timing 86/132: 085_signed_optional_256x320
Timing 87/132: 086_signed_required_320x256
Timing 88/132: 087_signed_optional_320x256
Timing 89/132: 088_rejection_optional_128x160
Timing 90/132: 089_rejection_optional_128x160
Timing 91/132: 090_rejection_optional_128x160
Timing 92/132: 091_rejection_optional_128x160
Timing 93/132: 092_rejection_optional_128x160
Timing 94/132: 093_rejection_optional_128x160
Timing 95/132: 094_rejection_optional_128x160
Timing 96/132: 095_rejection_optional_128x160
Timing 97/132: 096_rejection_optional_128x160
Timing 98/132: 097_rejection_optional_128x160
Timing 99/132: 098_rejection_optional_128x160
Timing 100/132: 099_rejection_optional_128x160
Timing 101/132: 100_rejection_optional_128x160
Timing 102/132: 101_rejection_optional_128x160
Timing 103/132: 102_rejection_optional_128x160
Timing 104/132: 103_rejection_optional_128x160
Timing 105/132: 104_rejection_optional_128x160
Timing 106/132: 105_rejection_optional_128x160
Timing 107/132: 106_rejection_optional_128x160
Timing 108/132: 107_rejection_optional_128x160
Timing 109/132: 108_rejection_optional_128x160
Timing 110/132: 109_rejection_optional_128x160
Timing 111/132: 110_rejection_optional_256x320
Timing 112/132: 111_rejection_optional_256x320
Timing 113/132: 112_rejection_optional_256x320
Timing 114/132: 113_rejection_optional_256x320
Timing 115/132: 114_rejection_optional_256x320
Timing 116/132: 115_rejection_optional_256x320
Timing 117/132: 116_rejection_optional_256x320
Timing 118/132: 117_rejection_optional_256x320
Timing 119/132: 118_rejection_optional_256x320
Timing 120/132: 119_rejection_optional_256x320
Timing 121/132: 120_rejection_optional_256x320
Timing 122/132: 121_rejection_optional_256x320
Timing 123/132: 122_rejection_optional_256x320
Timing 124/132: 123_rejection_optional_256x320
Timing 125/132: 124_rejection_optional_256x320
Timing 126/132: 125_rejection_optional_256x320
Timing 127/132: 126_rejection_optional_256x320
Timing 128/132: 127_rejection_optional_256x320
Timing 129/132: 128_rejection_optional_256x320
Timing 130/132: 129_rejection_optional_256x320
Timing 131/132: 130_rejection_optional_256x320
Timing 132/132: 131_rejection_optional_256x320
Memory 1/405: memory_required_256x256 jvrust
Memory 6/405: memory_required_256x256 jvcpp
Memory 11/405: memory_required_256x256 scipy
Memory 16/405: memory_required_256x256 jvx
Memory 21/405: memory_optional_256x256 jvrust
Memory 26/405: memory_optional_256x256 jvcpp
Memory 31/405: memory_optional_256x256 scipy_capped
Memory 36/405: memory_optional_256x256 scipy_dummies
Memory 41/405: memory_optional_256x256 scipy_square
Memory 46/405: memory_required_256x512 jvrust
Memory 51/405: memory_required_256x512 jvcpp
Memory 56/405: memory_required_256x512 scipy
Memory 61/405: memory_required_256x512 jvx
Memory 66/405: memory_optional_256x512 jvrust
Memory 71/405: memory_optional_256x512 jvcpp
Memory 76/405: memory_optional_256x512 scipy_capped
Memory 81/405: memory_optional_256x512 scipy_dummies
Memory 86/405: memory_optional_256x512 scipy_square
Memory 91/405: memory_required_512x256 jvrust
Memory 96/405: memory_required_512x256 jvcpp
Memory 101/405: memory_required_512x256 scipy
Memory 106/405: memory_required_512x256 jvx
Memory 111/405: memory_optional_512x256 jvrust
Memory 116/405: memory_optional_512x256 jvcpp
Memory 121/405: memory_optional_512x256 scipy_capped
Memory 126/405: memory_optional_512x256 scipy_dummies
Memory 131/405: memory_optional_512x256 scipy_square
Memory 136/405: memory_required_256x1024 jvrust
Memory 141/405: memory_required_256x1024 jvcpp
Memory 146/405: memory_required_256x1024 scipy
Memory 151/405: memory_required_256x1024 jvx
Memory 156/405: memory_optional_256x1024 jvrust
Memory 161/405: memory_optional_256x1024 jvcpp
Memory 166/405: memory_optional_256x1024 scipy_capped
Memory 171/405: memory_optional_256x1024 scipy_dummies
Memory 176/405: memory_optional_256x1024 scipy_square
Memory 181/405: memory_required_1024x256 jvrust
Memory 186/405: memory_required_1024x256 jvcpp
Memory 191/405: memory_required_1024x256 scipy
Memory 196/405: memory_required_1024x256 jvx
Memory 201/405: memory_optional_1024x256 jvrust
Memory 206/405: memory_optional_1024x256 jvcpp
Memory 211/405: memory_optional_1024x256 scipy_capped
Memory 216/405: memory_optional_1024x256 scipy_dummies
Memory 221/405: memory_optional_1024x256 scipy_square
Memory 226/405: memory_required_256x2048 jvrust
Memory 231/405: memory_required_256x2048 jvcpp
Memory 236/405: memory_required_256x2048 scipy
Memory 241/405: memory_required_256x2048 jvx
Memory 246/405: memory_optional_256x2048 jvrust
Memory 251/405: memory_optional_256x2048 jvcpp
Memory 256/405: memory_optional_256x2048 scipy_capped
Memory 261/405: memory_optional_256x2048 scipy_dummies
Memory 266/405: memory_optional_256x2048 scipy_square
Memory 271/405: memory_required_2048x256 jvrust
Memory 276/405: memory_required_2048x256 jvcpp
Memory 281/405: memory_required_2048x256 scipy
Memory 286/405: memory_required_2048x256 jvx
Memory 291/405: memory_optional_2048x256 jvrust
Memory 296/405: memory_optional_2048x256 jvcpp
Memory 301/405: memory_optional_2048x256 scipy_capped
Memory 306/405: memory_optional_2048x256 scipy_dummies
Memory 311/405: memory_optional_2048x256 scipy_square
Memory 316/405: memory_required_256x4096 jvrust
Memory 321/405: memory_required_256x4096 jvcpp
Memory 326/405: memory_required_256x4096 scipy
Memory 331/405: memory_required_256x4096 jvx
Memory 336/405: memory_optional_256x4096 jvrust
Memory 341/405: memory_optional_256x4096 jvcpp
Memory 346/405: memory_optional_256x4096 scipy_capped
Memory 351/405: memory_optional_256x4096 scipy_dummies
Memory 356/405: memory_optional_256x4096 scipy_square
Memory 361/405: memory_required_4096x256 jvrust
Memory 366/405: memory_required_4096x256 jvcpp
Memory 371/405: memory_required_4096x256 scipy
Memory 376/405: memory_required_4096x256 jvx
Memory 381/405: memory_optional_4096x256 jvrust
Memory 386/405: memory_optional_4096x256 jvcpp
Memory 391/405: memory_optional_4096x256 scipy_capped
Memory 396/405: memory_optional_4096x256 scipy_dummies
Memory 401/405: memory_optional_4096x256 scipy_square

Median milliseconds per matrix; ratio = method / reference (SciPy for R, capped SciPy for F)
000_large_square_required_1000x1000        JVRUST 4.530 (0.21), JVHYBRID 4.583 (0.21), JVCPP 4.728 (0.22), SciPy 21.612 (1.00)
001_large_square_optional_1000x1000        JVRUST 0.390 (0.10), JVCPP 0.371 (0.10), SciPy capped 3.855 (1.00), SciPy dummy cols 7.926 (2.06)
002_large_square_required_2000x2000        JVRUST 23.861 (0.22), JVHYBRID 24.181 (0.22), JVCPP 24.723 (0.22), SciPy 110.653 (1.00)
003_large_square_optional_2000x2000        JVRUST 1.726 (0.11), JVCPP 1.664 (0.10), SciPy capped 16.031 (1.00), SciPy dummy cols 35.978 (2.24)
004_large_square_required_3000x3000        JVRUST 63.862 (0.21), JVHYBRID 64.365 (0.21), JVCPP 65.168 (0.21), SciPy 309.346 (1.00)
005_large_square_optional_3000x3000        JVRUST 3.854 (0.09), JVCPP 3.716 (0.09), SciPy capped 41.291 (1.00), SciPy dummy cols 80.842 (1.96)
006_large_square_required_5000x5000        JVRUST 250.865 (0.24), JVHYBRID 250.545 (0.24), JVCPP 253.498 (0.24), SciPy 1046.714 (1.00)
007_large_square_optional_5000x5000        JVRUST 10.885 (0.09), JVCPP 10.590 (0.08), SciPy capped 126.454 (1.00), SciPy dummy cols 225.388 (1.78)
008_large_rectangle_required_1000x2000     JVRUST 1.060 (0.13), JVHYBRID 1.013 (0.13), JVCPP 1.013 (0.13), SciPy 7.895 (1.00)
009_large_rectangle_optional_1000x2000     JVRUST 0.720 (0.12), JVCPP 0.695 (0.11), SciPy capped 6.219 (1.00), SciPy dummy cols 9.571 (1.54)
010_large_rectangle_required_2000x1000     JVRUST 2.366 (0.24), JVHYBRID 2.298 (0.23), JVCPP 2.130 (0.21), SciPy 10.025 (1.00)
011_large_rectangle_optional_2000x1000     JVRUST 1.991 (0.22), JVCPP 1.781 (0.20), SciPy capped 9.083 (1.00), SciPy dummy cols 10.190 (1.12)
012_large_rectangle_required_2000x3000     JVRUST 3.592 (0.12), JVHYBRID 3.433 (0.11), JVCPP 3.427 (0.11), SciPy 30.744 (1.00)
013_large_rectangle_optional_2000x3000     JVRUST 2.299 (0.10), JVCPP 2.217 (0.09), SciPy capped 23.505 (1.00), SciPy dummy cols 39.732 (1.69)
014_large_rectangle_required_3000x2000     JVRUST 17.081 (0.36), JVHYBRID 17.002 (0.36), JVCPP 16.525 (0.35), SciPy 47.409 (1.00)
015_large_rectangle_optional_3000x2000     JVRUST 15.889 (0.38), JVCPP 15.360 (0.37), SciPy capped 41.983 (1.00), SciPy dummy cols 42.987 (1.02)
016_large_rectangle_required_4000x5000     JVRUST 15.015 (0.11), JVHYBRID 14.405 (0.11), JVCPP 14.402 (0.11), SciPy 131.596 (1.00)
017_large_rectangle_optional_4000x5000     JVRUST 8.092 (0.09), JVCPP 7.872 (0.09), SciPy capped 90.846 (1.00), SciPy dummy cols 150.541 (1.66)
018_large_rectangle_required_5000x4000     JVRUST 61.349 (0.29), JVHYBRID 60.755 (0.28), JVCPP 60.830 (0.28), SciPy 214.820 (1.00)
019_large_rectangle_optional_5000x4000     JVRUST 54.856 (0.31), JVCPP 54.827 (0.31), SciPy capped 174.818 (1.00), SciPy dummy cols 163.591 (0.94)
020_extreme_rectangle_required_64x4096     JVRUST 0.086 (0.17), JVHYBRID 0.077 (0.15), JVCPP 0.077 (0.15), SciPy 0.520 (1.00)
021_extreme_rectangle_optional_64x4096     JVRUST 0.058 (0.10), JVCPP 0.053 (0.09), SciPy capped 0.587 (1.00), SciPy dummy cols 0.586 (1.00)
022_extreme_rectangle_required_4096x64     JVRUST 0.206 (0.20), JVHYBRID 0.199 (0.19), JVCPP 0.575 (0.55), SciPy 1.045 (1.00)
023_extreme_rectangle_optional_4096x64     JVRUST 0.176 (0.10), JVCPP 0.549 (0.32), SciPy capped 1.694 (1.00), SciPy dummy cols 0.785 (0.46)
024_extreme_rectangle_required_64x8192     JVRUST 0.163 (0.16), JVHYBRID 0.149 (0.15), JVCPP 0.149 (0.15), SciPy 1.024 (1.00)
025_extreme_rectangle_optional_64x8192     JVRUST 0.115 (0.10), JVCPP 0.105 (0.09), SciPy capped 1.178 (1.00), SciPy dummy cols 1.149 (0.97)
026_extreme_rectangle_required_8192x64     JVRUST 0.415 (0.20), JVHYBRID 0.397 (0.19), JVCPP 1.136 (0.55), SciPy 2.074 (1.00)
027_extreme_rectangle_optional_8192x64     JVRUST 0.367 (0.11), JVCPP 1.100 (0.33), SciPy capped 3.308 (1.00), SciPy dummy cols 1.894 (0.57)
028_extreme_rectangle_required_64x16384    JVRUST 0.371 (0.18), JVHYBRID 0.347 (0.16), JVCPP 0.346 (0.16), SciPy 2.107 (1.00)
029_extreme_rectangle_optional_64x16384    JVRUST 0.294 (0.12), JVCPP 0.278 (0.11), SciPy capped 2.455 (1.00), SciPy dummy cols 2.338 (0.95)
030_extreme_rectangle_required_16384x64    JVRUST 1.053 (0.25), JVHYBRID 1.025 (0.24), JVCPP 2.282 (0.55), SciPy 4.186 (1.00)
031_extreme_rectangle_optional_16384x64    JVRUST 0.954 (0.14), JVCPP 2.207 (0.33), SciPy capped 6.747 (1.00), SciPy dummy cols 4.118 (0.61)
032_congestion_required_256x320            JVRUST 0.115 (0.21), JVHYBRID 0.106 (0.20), JVCPP 0.107 (0.20), SciPy 0.543 (1.00)
033_congestion_optional_256x320            JVRUST 0.063 (0.13), JVCPP 0.065 (0.14), SciPy capped 0.473 (1.00), SciPy dummy cols 0.771 (1.63)
034_congestion_required_256x320            JVRUST 0.624 (0.51), JVHYBRID 0.617 (0.51), JVCPP 0.638 (0.52), SciPy 1.220 (1.00)
035_congestion_optional_256x320            JVRUST 0.521 (0.68), JVCPP 0.536 (0.70), SciPy capped 0.762 (1.00), SciPy dummy cols 1.408 (1.85)
036_congestion_required_256x320            JVRUST 0.772 (0.58), JVHYBRID 0.763 (0.58), JVCPP 0.797 (0.60), SciPy 1.322 (1.00)
037_congestion_optional_256x320            JVRUST 0.611 (0.78), JVCPP 0.633 (0.81), SciPy capped 0.785 (1.00), SciPy dummy cols 1.483 (1.89)
038_congestion_required_256x320            JVRUST 0.884 (0.64), JVHYBRID 0.879 (0.64), JVCPP 0.921 (0.67), SciPy 1.382 (1.00)
039_congestion_optional_256x320            JVRUST 0.711 (0.91), JVCPP 0.732 (0.93), SciPy capped 0.784 (1.00), SciPy dummy cols 1.552 (1.98)
040_congestion_required_256x320            JVRUST 1.008 (0.72), JVHYBRID 1.005 (0.72), JVCPP 1.052 (0.75), SciPy 1.402 (1.00)
041_congestion_optional_256x320            JVRUST 0.799 (1.01), JVCPP 0.828 (1.04), SciPy capped 0.793 (1.00), SciPy dummy cols 1.584 (2.00)
042_forbidden_required_256x320             JVRUST 0.091 (0.17), JVHYBRID 0.084 (0.15), JVCPP 0.084 (0.16), SciPy 0.540 (1.00)
043_forbidden_optional_256x320             JVRUST 0.027 (0.09), JVCPP 0.027 (0.09), SciPy capped 0.303 (1.00), SciPy dummy cols 0.522 (1.72)
044_forbidden_required_256x320             JVRUST 0.093 (0.12), JVHYBRID 0.086 (0.11), JVCPP 0.087 (0.11), SciPy 0.793 (1.00)
045_forbidden_optional_256x320             JVRUST 0.022 (0.08), JVCPP 0.022 (0.08), SciPy capped 0.286 (1.00), SciPy dummy cols 0.699 (2.44)
046_forbidden_required_256x320             JVRUST 0.090 (0.19), JVHYBRID 0.083 (0.17), JVCPP 0.082 (0.17), SciPy 0.473 (1.00)
047_forbidden_optional_256x320             JVRUST 0.020 (0.08), JVCPP 0.020 (0.08), SciPy capped 0.246 (1.00), SciPy dummy cols 0.423 (1.72)
048_forbidden_required_256x320             JVRUST 0.071 (0.21), JVHYBRID 0.066 (0.20), JVCPP 0.065 (0.19), SciPy 0.333 (1.00)
049_forbidden_optional_256x320             JVRUST 0.020 (0.09), JVCPP 0.019 (0.08), SciPy capped 0.232 (1.00), SciPy dummy cols 0.368 (1.58)
050_ties_required_256x320                  JVRUST 0.034 (0.16), JVHYBRID 0.032 (0.15), JVCPP 0.032 (0.15), SciPy 0.213 (1.00)
051_ties_optional_256x320                  JVRUST 0.028 (0.12), JVCPP 0.027 (0.12), SciPy capped 0.231 (1.00), SciPy dummy cols 0.371 (1.61)
052_ties_required_256x320                  JVRUST 0.038 (0.08), JVHYBRID 0.036 (0.07), JVCPP 0.036 (0.07), SciPy 0.483 (1.00)
053_ties_optional_256x320                  JVRUST 0.032 (0.06), JVCPP 0.031 (0.06), SciPy capped 0.499 (1.00), SciPy dummy cols 0.638 (1.28)
054_ties_required_256x320                  JVRUST 0.045 (0.16), JVHYBRID 0.043 (0.15), JVCPP 0.045 (0.16), SciPy 0.288 (1.00)
055_ties_optional_256x320                  JVRUST 0.036 (0.12), JVCPP 0.036 (0.12), SciPy capped 0.305 (1.00), SciPy dummy cols 0.445 (1.46)
056_ties_required_256x320                  JVRUST 0.113 (0.26), JVHYBRID 0.108 (0.25), JVCPP 0.112 (0.26), SciPy 0.428 (1.00)
057_ties_optional_256x320                  JVRUST 0.097 (0.24), JVCPP 0.099 (0.24), SciPy capped 0.408 (1.00), SciPy dummy cols 0.629 (1.54)
058_congestion_required_512x640            JVRUST 0.354 (0.16), JVHYBRID 0.330 (0.15), JVCPP 0.332 (0.15), SciPy 2.190 (1.00)
059_congestion_optional_512x640            JVRUST 0.218 (0.11), JVCPP 0.217 (0.11), SciPy capped 1.911 (1.00), SciPy dummy cols 3.134 (1.64)
060_congestion_required_512x640            JVRUST 2.360 (0.45), JVHYBRID 2.339 (0.45), JVCPP 2.419 (0.46), SciPy 5.217 (1.00)
061_congestion_optional_512x640            JVRUST 1.945 (0.58), JVCPP 2.003 (0.60), SciPy capped 3.343 (1.00), SciPy dummy cols 6.311 (1.89)
062_congestion_required_512x640            JVRUST 2.973 (0.55), JVHYBRID 2.947 (0.54), JVCPP 3.091 (0.57), SciPy 5.440 (1.00)
063_congestion_optional_512x640            JVRUST 2.459 (0.72), JVCPP 2.540 (0.74), SciPy capped 3.413 (1.00), SciPy dummy cols 6.582 (1.93)
064_congestion_required_512x640            JVRUST 3.525 (0.61), JVHYBRID 3.494 (0.60), JVCPP 3.672 (0.63), SciPy 5.801 (1.00)
065_congestion_optional_512x640            JVRUST 2.779 (0.80), JVCPP 2.872 (0.83), SciPy capped 3.457 (1.00), SciPy dummy cols 6.783 (1.96)
066_congestion_required_512x640            JVRUST 3.850 (0.64), JVHYBRID 3.816 (0.63), JVCPP 4.036 (0.67), SciPy 6.020 (1.00)
067_congestion_optional_512x640            JVRUST 3.255 (0.93), JVCPP 3.374 (0.97), SciPy capped 3.493 (1.00), SciPy dummy cols 6.987 (2.00)
068_forbidden_required_512x640             JVRUST 0.306 (0.13), JVHYBRID 0.282 (0.12), JVCPP 0.282 (0.12), SciPy 2.286 (1.00)
069_forbidden_optional_512x640             JVRUST 0.100 (0.09), JVCPP 0.094 (0.08), SciPy capped 1.148 (1.00), SciPy dummy cols 2.095 (1.82)
070_forbidden_required_512x640             JVRUST 0.302 (0.09), JVHYBRID 0.277 (0.09), JVCPP 0.278 (0.09), SciPy 3.229 (1.00)
071_forbidden_optional_512x640             JVRUST 0.085 (0.08), JVCPP 0.080 (0.08), SciPy capped 1.061 (1.00), SciPy dummy cols 2.773 (2.61)
072_forbidden_required_512x640             JVRUST 0.284 (0.16), JVHYBRID 0.257 (0.14), JVCPP 0.257 (0.14), SciPy 1.790 (1.00)
073_forbidden_optional_512x640             JVRUST 0.076 (0.08), JVCPP 0.071 (0.07), SciPy capped 0.965 (1.00), SciPy dummy cols 1.700 (1.76)
074_forbidden_required_512x640             JVRUST 0.224 (0.18), JVHYBRID 0.200 (0.16), JVCPP 0.198 (0.16), SciPy 1.243 (1.00)
075_forbidden_optional_512x640             JVRUST 0.075 (0.08), JVCPP 0.069 (0.07), SciPy capped 0.926 (1.00), SciPy dummy cols 1.468 (1.58)
076_ties_required_512x640                  JVRUST 0.128 (0.16), JVHYBRID 0.117 (0.14), JVCPP 0.119 (0.14), SciPy 0.825 (1.00)
077_ties_optional_512x640                  JVRUST 0.101 (0.11), JVCPP 0.097 (0.11), SciPy capped 0.908 (1.00), SciPy dummy cols 1.472 (1.62)
078_ties_required_512x640                  JVRUST 0.140 (0.07), JVHYBRID 0.126 (0.07), JVCPP 0.128 (0.07), SciPy 1.889 (1.00)
079_ties_optional_512x640                  JVRUST 0.110 (0.06), JVCPP 0.107 (0.05), SciPy capped 1.981 (1.00), SciPy dummy cols 2.546 (1.29)
080_ties_required_512x640                  JVRUST 0.152 (0.13), JVHYBRID 0.144 (0.13), JVCPP 0.149 (0.13), SciPy 1.129 (1.00)
081_ties_optional_512x640                  JVRUST 0.122 (0.10), JVCPP 0.121 (0.10), SciPy capped 1.211 (1.00), SciPy dummy cols 1.778 (1.47)
082_ties_required_512x640                  JVRUST 0.416 (0.27), JVHYBRID 0.406 (0.26), JVCPP 0.416 (0.27), SciPy 1.540 (1.00)
083_ties_optional_512x640                  JVRUST 0.381 (0.27), JVCPP 0.384 (0.27), SciPy capped 1.435 (1.00), SciPy dummy cols 2.321 (1.62)
084_signed_required_256x320                JVRUST 0.098 (0.12), JVHYBRID 0.090 (0.11), JVCPP 0.091 (0.11), SciPy 0.799 (1.00)
085_signed_optional_256x320                JVRUST 0.064 (0.13), JVCPP 0.066 (0.14), SciPy capped 0.480 (1.00), SciPy dummy cols 1.036 (2.16)
086_signed_required_320x256                JVRUST 0.130 (0.14), JVHYBRID 0.122 (0.14), JVCPP 0.118 (0.13), SciPy 0.897 (1.00)
087_signed_optional_320x256                JVRUST 0.097 (0.17), JVCPP 0.094 (0.16), SciPy capped 0.582 (1.00), SciPy dummy cols 1.060 (1.82)
088_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.062 (1.00), SciPy dummy cols 0.157 (2.52)
089_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.063 (1.00), SciPy dummy cols 0.157 (2.48)
090_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.10), SciPy capped 0.064 (1.00), SciPy dummy cols 0.158 (2.48)
091_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.10), SciPy capped 0.065 (1.00), SciPy dummy cols 0.158 (2.44)
092_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.069 (1.00), SciPy dummy cols 0.162 (2.35)
093_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.007 (0.09), SciPy capped 0.074 (1.00), SciPy dummy cols 0.171 (2.31)
094_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.008 (0.09), SciPy capped 0.083 (1.00), SciPy dummy cols 0.188 (2.27)
095_rejection_optional_128x160             JVRUST 0.008 (0.09), JVCPP 0.012 (0.13), SciPy capped 0.095 (1.00), SciPy dummy cols 0.232 (2.45)
096_rejection_optional_128x160             JVRUST 0.011 (0.11), JVCPP 0.015 (0.15), SciPy capped 0.099 (1.00), SciPy dummy cols 0.246 (2.49)
097_rejection_optional_128x160             JVRUST 0.014 (0.12), JVCPP 0.018 (0.15), SciPy capped 0.122 (1.00), SciPy dummy cols 0.247 (2.03)
098_rejection_optional_128x160             JVRUST 0.016 (0.12), JVCPP 0.020 (0.15), SciPy capped 0.134 (1.00), SciPy dummy cols 0.247 (1.84)
099_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.062 (1.00), SciPy dummy cols 0.094 (1.51)
100_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.063 (1.00), SciPy dummy cols 0.095 (1.50)
101_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.064 (1.00), SciPy dummy cols 0.095 (1.49)
102_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.065 (1.00), SciPy dummy cols 0.095 (1.46)
103_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.068 (1.00), SciPy dummy cols 0.098 (1.43)
104_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.007 (0.09), SciPy capped 0.072 (1.00), SciPy dummy cols 0.101 (1.40)
105_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.007 (0.09), SciPy capped 0.079 (1.00), SciPy dummy cols 0.116 (1.47)
106_rejection_optional_128x160             JVRUST 0.008 (0.08), JVCPP 0.010 (0.11), SciPy capped 0.098 (1.00), SciPy dummy cols 0.175 (1.79)
107_rejection_optional_128x160             JVRUST 0.021 (0.16), JVCPP 0.022 (0.17), SciPy capped 0.131 (1.00), SciPy dummy cols 0.255 (1.95)
108_rejection_optional_128x160             JVRUST 0.188 (1.03), JVCPP 0.196 (1.07), SciPy capped 0.184 (1.00), SciPy dummy cols 0.340 (1.85)
109_rejection_optional_128x160             JVRUST 0.233 (0.70), JVCPP 0.242 (0.72), SciPy capped 0.334 (1.00), SciPy dummy cols 0.447 (1.34)
110_rejection_optional_256x320             JVRUST 0.020 (0.09), JVCPP 0.019 (0.08), SciPy capped 0.230 (1.00), SciPy dummy cols 0.639 (2.78)
111_rejection_optional_256x320             JVRUST 0.020 (0.08), JVCPP 0.019 (0.08), SciPy capped 0.239 (1.00), SciPy dummy cols 0.631 (2.65)
112_rejection_optional_256x320             JVRUST 0.020 (0.08), JVCPP 0.019 (0.08), SciPy capped 0.243 (1.00), SciPy dummy cols 0.632 (2.60)
113_rejection_optional_256x320             JVRUST 0.020 (0.08), JVCPP 0.020 (0.08), SciPy capped 0.253 (1.00), SciPy dummy cols 0.643 (2.55)
114_rejection_optional_256x320             JVRUST 0.022 (0.08), JVCPP 0.022 (0.08), SciPy capped 0.272 (1.00), SciPy dummy cols 0.677 (2.49)
115_rejection_optional_256x320             JVRUST 0.025 (0.09), JVCPP 0.025 (0.08), SciPy capped 0.297 (1.00), SciPy dummy cols 0.742 (2.50)
116_rejection_optional_256x320             JVRUST 0.037 (0.11), JVCPP 0.036 (0.11), SciPy capped 0.337 (1.00), SciPy dummy cols 0.883 (2.62)
117_rejection_optional_256x320             JVRUST 0.054 (0.14), JVCPP 0.055 (0.14), SciPy capped 0.386 (1.00), SciPy dummy cols 1.060 (2.74)
118_rejection_optional_256x320             JVRUST 0.058 (0.14), JVCPP 0.060 (0.15), SciPy capped 0.410 (1.00), SciPy dummy cols 1.066 (2.60)
119_rejection_optional_256x320             JVRUST 0.068 (0.13), JVCPP 0.070 (0.13), SciPy capped 0.541 (1.00), SciPy dummy cols 1.071 (1.98)
120_rejection_optional_256x320             JVRUST 0.072 (0.12), JVCPP 0.074 (0.12), SciPy capped 0.592 (1.00), SciPy dummy cols 1.070 (1.81)
121_rejection_optional_256x320             JVRUST 0.020 (0.09), JVCPP 0.019 (0.08), SciPy capped 0.230 (1.00), SciPy dummy cols 0.366 (1.59)
122_rejection_optional_256x320             JVRUST 0.020 (0.08), JVCPP 0.019 (0.08), SciPy capped 0.243 (1.00), SciPy dummy cols 0.362 (1.49)
123_rejection_optional_256x320             JVRUST 0.020 (0.08), JVCPP 0.019 (0.08), SciPy capped 0.240 (1.00), SciPy dummy cols 0.364 (1.52)
124_rejection_optional_256x320             JVRUST 0.021 (0.08), JVCPP 0.020 (0.08), SciPy capped 0.248 (1.00), SciPy dummy cols 0.383 (1.54)
125_rejection_optional_256x320             JVRUST 0.022 (0.08), JVCPP 0.021 (0.08), SciPy capped 0.266 (1.00), SciPy dummy cols 0.402 (1.51)
126_rejection_optional_256x320             JVRUST 0.024 (0.08), JVCPP 0.024 (0.08), SciPy capped 0.299 (1.00), SciPy dummy cols 0.487 (1.63)
127_rejection_optional_256x320             JVRUST 0.031 (0.09), JVCPP 0.031 (0.09), SciPy capped 0.336 (1.00), SciPy dummy cols 0.634 (1.89)
128_rejection_optional_256x320             JVRUST 0.070 (0.15), JVCPP 0.067 (0.14), SciPy capped 0.472 (1.00), SciPy dummy cols 1.003 (2.12)
129_rejection_optional_256x320             JVRUST 0.151 (0.22), JVCPP 0.148 (0.22), SciPy capped 0.679 (1.00), SciPy dummy cols 1.437 (2.12)
130_rejection_optional_256x320             JVRUST 0.695 (0.88), JVCPP 0.720 (0.91), SciPy capped 0.792 (1.00), SciPy dummy cols 1.528 (1.93)
131_rejection_optional_256x320             JVRUST 0.872 (0.62), JVCPP 0.901 (0.65), SciPy capped 1.397 (1.00), SciPy dummy cols 1.917 (1.37)
{
  "status": "completed",
  "started_utc": "2026-10-29T15:15:34.203779+00:00",
  "python_executable": "<python>/bin/python",
  "source_sha256": "a3c45d1b3833fe768b49e9c3a0e78199974ffbdf957f403d8e519b097dcab17e",
  "planned_timing_cases": 132,
  "planned_memory_trials": 405,
  "timing_cases": 132,
  "timing_samples": 4752,
  "completed_method_settings": 528,
  "memory_trials": 405,
  "objective_checks": 2112,
  "excluded_method_settings": 0,
  "completed_utc": "2026-10-29T15:25:00.943273+00:00",
  "failures": 0
}
All selected suites completed: <output>
(l31118) ratha@home:/media/ratha/HOT/DEV/projects/lapx_all/new8/lap-paper$ conda deactivate
conda activate l31410
(l31410) ratha@home:/media/ratha/HOT/DEV/projects/lapx_all/new8/lap-paper$ python -m pip install -r benchmark/requirements-py314.txt
Collecting lapx==0.13.0 (from -r benchmark/requirements-py314.txt (line 2))
  Downloading lapx-0.13.0-cp314-cp314-manylinux_2_28_x86_64.whl.metadata (25 kB)
Collecting laprust==1.2.0 (from -r benchmark/requirements-py314.txt (line 3))
  Downloading laprust-1.2.0-cp314-cp314-manylinux_2_28_x86_64.whl.metadata (9.7 kB)
Collecting lapcpp==1.2.0 (from -r benchmark/requirements-py314.txt (line 4))
  Downloading lapcpp-1.2.0-cp314-cp314-manylinux_2_24_x86_64.manylinux_2_28_x86_64.whl.metadata (9.7 kB)
Collecting numpy==2.5.4 (from -r benchmark/requirements-py314.txt (line 5))
  Using cached numpy-2.5.4-cp314-cp314-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl.metadata (6.6 kB)
Collecting scipy==1.18.1 (from -r benchmark/requirements-py314.txt (line 6))
  Using cached scipy-1.18.1-cp314-cp314-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl.metadata (62 kB)
Collecting psutil==7.2.2 (from -r benchmark/requirements-py314.txt (line 7))
  Using cached psutil-7.2.2-cp36-abi3-manylinux2010_x86_64.manylinux_2_12_x86_64.manylinux_2_28_x86_64.whl.metadata (22 kB)
Collecting threadpoolctl==3.7.0 (from -r benchmark/requirements-py314.txt (line 8))
  Using cached threadpoolctl-3.7.0-py3-none-any.whl.metadata (24 kB)
Downloading lapx-0.13.0-cp314-cp314-manylinux_2_28_x86_64.whl (4.0 MB)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 4.0/4.0 MB 9.7 MB/s  0:00:00
Downloading laprust-1.2.0-cp314-cp314-manylinux_2_28_x86_64.whl (1.8 MB)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 1.8/1.8 MB 10.0 MB/s  0:00:00
Downloading lapcpp-1.2.0-cp314-cp314-manylinux_2_24_x86_64.manylinux_2_28_x86_64.whl (622 kB)
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 622.3/622.3 kB 2.8 MB/s  0:00:00
Using cached numpy-2.5.4-cp314-cp314-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl (16.7 MB)
Using cached scipy-1.18.1-cp314-cp314-manylinux_2_27_x86_64.manylinux_2_28_x86_64.whl (35.3 MB)
Using cached psutil-7.2.2-cp36-abi3-manylinux2010_x86_64.manylinux_2_12_x86_64.manylinux_2_28_x86_64.whl (155 kB)
Using cached threadpoolctl-3.7.0-py3-none-any.whl (26 kB)
Installing collected packages: threadpoolctl, psutil, numpy, scipy, lapx, laprust, lapcpp
Successfully installed lapcpp-1.2.0 laprust-1.2.0 lapx-0.13.0 numpy-2.5.4 psutil-7.2.2 scipy-1.18.1 threadpoolctl-3.7.0
(l31410) ratha@home:/media/ratha/HOT/DEV/projects/lapx_all/new8/lap-paper$ python benchmark/run_all.py --output benchmark/runs/full-linux-p314-20261029 --cpu 0 --batch-cpus 0 2 4 6
== base: run.py --output <output>/base --cpu 0 --batch-cpus 0 2 4 6
Validation 16800 calls passed
Single square128
Single square512
Single wide64x512
Single tall512x64
Single near256x320
Single blocks256x320
Single ties128x160
Single optional128x160
Single optional256x320
Single tight128x160
Single negative128x160
Single optional_square128
Batch batch64x64x80
Batch batch16x128x160_optional
Batch batch1024x8x10
Memory required jvrust
Memory required jvhybrid
Memory required jvcpp
Memory required jvx
Memory required scipy
Memory optional jvrust
Memory optional jvhybrid
Memory optional jvcpp
Memory optional jvx
Memory optional scipy

Table 4: median microseconds per matrix
case                    JVRUST  JVHYBRID     JVCPP       JVX       JVS       JVC     SciPy
square128                 70.7      69.1      72.0     131.1     128.2     238.8     262.7
square512               1091.8    1097.7    1162.6    3995.4    3998.3    5351.8    4968.5
wide64x512                15.7      14.8      15.8     453.4     405.8     973.2      71.9
tall512x64                29.7      27.1      78.0     469.5     420.9    1225.9     140.9
near256x320               91.4      84.6      91.0     172.4     173.6    3841.8     545.6
blocks256x320            909.1     889.3     936.4   11690.9   11803.0    5270.5    1406.2
ties128x160               13.3      13.0      13.5      55.5      54.5      79.8      77.8
optional128x160           13.7      13.6      17.3     429.7     426.7    1956.8     428.6
optional256x320           69.2      68.7      71.3    2613.6    2581.3   13518.4    1742.4
tight128x160               9.0       9.1      13.3     369.3     363.8    2265.4    1059.4
negative128x160           14.3      14.2      17.8     856.5     862.3    2707.7     432.4
optional_square128        75.1      75.7      79.9     207.0     206.0     460.9     500.2

Table 5: median milliseconds per complete batch
  batch64x64x80: jvcpp_batch_t1 0.816, jvcpp_batch_t4 0.296, jvhybrid_batch_t1 0.764, jvhybrid_batch_t4 0.217, jvrust_batch_t1 0.773, jvrust_batch_t4 0.229, jvrust_loop 0.863, jvx_batch_t1 1.582, jvx_batch_t4 1.496, scipy_loop 2.658
  batch16x128x160_optional: jvcpp_batch_t1 0.419, jvcpp_batch_t4 0.169, jvhybrid_batch_t1 0.409, jvhybrid_batch_t4 0.118, jvrust_batch_t1 0.391, jvrust_batch_t4 0.126, jvrust_loop 0.397, jvx_batch_t1 7.555, jvx_batch_t4 2.422, scipy_loop 7.688
  batch1024x8x10: jvcpp_batch_t1 0.565, jvcpp_batch_t4 0.248, jvhybrid_batch_t1 0.561, jvhybrid_batch_t4 0.195, jvrust_batch_t1 0.562, jvrust_batch_t4 0.199, jvrust_loop 1.082, jvx_batch_t1 5.187, jvx_batch_t4 10.447, scipy_loop 2.265

Table 6: additional peak for 256 x 4096 (MiB)
  required  JVRUST         0.00
  required  JVHYBRID       0.00
  required  JVCPP          0.00
  required  JVX          118.18
  required  SciPy          0.00
  optional  JVRUST         0.00
  optional  JVHYBRID       0.00
  optional  JVCPP          0.00
  optional  JVX          134.48
  optional  SciPy        134.37

Results saved: <benchmark>/runs/full-linux-p314-20261029/base
== formulations: run.py --output <output>/formulations --cpu 0
Independent optional validation passed: 10500
optional128x160 mean pairs 128.0
optional256x320 mean pairs 256.0
tight128x160 mean pairs 119.75
negative128x160 mean pairs 128.0
optional_square128 mean pairs 128.0
reject128x160_L005 mean pairs 40.25
reject128x160_L001 mean pairs 11.0
reject_tall160x128 mean pairs 38.5
optional_wide64x512 mean pairs 46.0
optional_blocks256x320 mean pairs 144.0

Table 7: median microseconds per matrix; Unmatched = mean smaller-side unmatched rows
case                               JVRUST            JVCPP     SciPy square SciPy dummy cols     SciPy capped  Unmatched
optional128x160                      13.7             17.4            428.7            249.3            124.4       0.00
optional256x320                      69.4             71.2           1753.1           1064.8            536.9       0.00
tight128x160                          9.1             13.4           1053.5            244.5            108.2       8.25
negative128x160                      14.4             17.9            424.9            233.8            138.2       0.00
optional_square128                   75.1             79.9            500.4            392.8            214.1       0.00
reject128x160_L005                    5.7              6.5            820.0            165.7             73.2      87.75
reject128x160_L001                    5.4              6.1            502.7            159.3             64.1     117.00
reject_tall160x128                   14.2             12.1            848.0            169.5             76.9      89.50
optional_wide64x512                   8.4              8.4           1567.9            193.8             84.2      18.00
optional_blocks256x320              680.7            705.3           2071.4           1373.1            706.3     112.00

Results saved: <benchmark>/runs/full-linux-p314-20261029/formulations
== scaling: run.py --output <output>/scaling --cpu 0
1/47 required_square_16x16 unmatched=0.00 elapsed=1.0s
2/47 required_square_32x32 unmatched=0.00 elapsed=1.9s
3/47 required_square_64x64 unmatched=0.00 elapsed=3.4s
4/47 required_square_128x128 unmatched=0.00 elapsed=5.2s
5/47 required_square_256x256 unmatched=0.00 elapsed=7.1s
6/47 required_square_512x512 unmatched=0.00 elapsed=9.1s
7/47 required_square_1024x1024 unmatched=0.00 elapsed=13.4s
8/47 required_wide_16x64 unmatched=0.00 elapsed=14.6s
9/47 required_wide_32x128 unmatched=0.00 elapsed=15.9s
10/47 required_wide_64x256 unmatched=0.00 elapsed=17.5s
11/47 required_wide_128x512 unmatched=0.00 elapsed=19.4s
12/47 required_wide_256x1024 unmatched=0.00 elapsed=22.1s
13/47 required_wide_512x2048 unmatched=0.00 elapsed=32.1s
14/47 required_fixed_64x64 unmatched=0.00 elapsed=33.7s
15/47 required_fixed_64x128 unmatched=0.00 elapsed=35.2s
16/47 required_fixed_64x256 unmatched=0.00 elapsed=36.7s
17/47 required_fixed_64x512 unmatched=0.00 elapsed=38.5s
18/47 required_fixed_64x1024 unmatched=0.00 elapsed=40.3s
19/47 required_fixed_64x2048 unmatched=0.00 elapsed=43.1s
20/47 required_fixed_64x4096 unmatched=0.00 elapsed=51.8s
21/47 optional_square_16x16 unmatched=0.00 elapsed=52.7s
22/47 optional_square_32x32 unmatched=0.00 elapsed=53.8s
23/47 optional_square_64x64 unmatched=0.00 elapsed=55.2s
24/47 optional_square_128x128 unmatched=0.00 elapsed=56.9s
25/47 optional_square_256x256 unmatched=0.00 elapsed=58.6s
26/47 optional_square_512x512 unmatched=0.00 elapsed=60.7s
27/47 optional_square_1024x1024 unmatched=0.00 elapsed=68.2s
28/47 optional_wide_16x64 unmatched=0.00 elapsed=69.4s
29/47 optional_wide_32x128 unmatched=0.00 elapsed=70.6s
30/47 optional_wide_64x256 unmatched=0.00 elapsed=72.1s
31/47 optional_wide_128x512 unmatched=0.00 elapsed=74.0s
32/47 optional_wide_256x1024 unmatched=0.00 elapsed=80.8s
33/47 optional_wide_512x2048 unmatched=0.00 elapsed=126.2s
34/47 optional_fixed_64x64 unmatched=0.00 elapsed=127.7s
35/47 optional_fixed_64x128 unmatched=0.00 elapsed=129.0s
36/47 optional_fixed_64x256 unmatched=0.00 elapsed=130.4s
37/47 optional_fixed_64x512 unmatched=0.00 elapsed=132.2s
38/47 optional_fixed_64x1024 unmatched=0.00 elapsed=138.0s
39/47 optional_fixed_64x2048 unmatched=0.00 elapsed=175.7s
40/47 optional_fixed_64x4096 unmatched=0.00 elapsed=538.3s
41/47 optional_blocks_16x20 unmatched=7.00 elapsed=539.5s
42/47 optional_blocks_32x40 unmatched=14.00 elapsed=540.8s
43/47 optional_blocks_64x80 unmatched=28.00 elapsed=542.4s
44/47 optional_blocks_128x160 unmatched=56.00 elapsed=544.2s
45/47 optional_blocks_256x320 unmatched=112.00 elapsed=546.0s
46/47 optional_blocks_512x640 unmatched=224.00 elapsed=551.1s
47/47 optional_blocks_1024x1280 unmatched=448.00 elapsed=582.3s

Median microseconds per matrix (Figures 6-8)

optional blocks
shape                  JVRUST            JVCPP              JVX     SciPy square SciPy dummy cols     SciPy capped
16x20                    1.0              1.0              9.7              9.4              5.0              4.4
32x40                    2.3              2.6             39.0             31.8             18.7             12.1
64x80                   30.9             35.4            219.7            122.5             75.7             42.4
128x160                 176.7            183.3           1282.5            533.0            355.0            189.5
256x320                 699.4            725.7           8468.5           2240.2           1522.6            776.9
512x640                2854.4           2947.9          73126.3           9337.2           6639.5           3397.9
1024x1280              11226.1          11582.3         587357.4          45842.8          32252.7          16417.9

optional fixed
shape                  JVRUST            JVCPP              JVX     SciPy square SciPy dummy cols     SciPy capped
64x64                   20.2             22.4             56.4            109.1             79.9             51.4
64x128                   3.2              4.9            331.2            141.1             47.4             36.2
64x256                   4.9              7.3           1884.7            327.7             61.7             50.7
64x512                   9.3             10.8          12211.9            978.7             86.9             81.5
64x1024                 16.8             17.8         100177.7           3387.6            151.8            145.6
64x2048                 31.1             30.9         818266.4          14810.4            300.7            294.3
64x4096                 60.5             57.6        8144453.1          57824.4            585.3            571.9

optional square
shape                  JVRUST            JVCPP              JVX     SciPy square SciPy dummy cols     SciPy capped
16x16                    1.1              1.1              7.0              9.2              5.0              4.1
32x32                    2.7              2.8             17.0             30.2             18.6             10.3
64x64                   14.3             16.6             56.4            108.1             79.0             51.1
128x128                  91.7             96.8            314.1            487.0            380.2            242.4
256x256                 411.1            416.7           1294.2           2148.1           1738.4           1059.5
512x512                2020.0           2045.4           6028.9           9865.6           8276.2           4750.3
1024x1024              11007.5          11090.1          25384.9          50317.8          42210.9          23085.5

optional wide
shape                  JVRUST            JVCPP              JVX     SciPy square SciPy dummy cols     SciPy capped
16x64                    1.0              1.0             54.1             26.4              6.3              5.7
32x128                   1.8              2.0            305.6             89.5             17.9             14.3
64x256                   4.8              6.9           1876.6            323.5             58.2             47.9
128x512                  22.8             24.2          14057.6           1276.2            226.2            189.1
256x1024                 86.3             83.8         118286.2           4968.0            921.2            767.7
512x2048                381.2            368.3         973701.3          23404.8           3800.8           3158.5

required fixed
shape                  JVRUST         JVHYBRID            JVCPP              JVX              JVS              JVC            SciPy
64x64                   16.2             15.5             16.2             21.0             17.3             43.6             50.2
64x128                   8.4              8.0              8.7             32.7             35.5            225.2             33.0
64x256                  10.8             10.3             10.9            113.3            107.5            523.7             46.5
64x512                  15.9             15.1             16.1            457.2            405.0           1199.7             75.7
64x1024                 25.9             24.0             25.0           1827.4           1603.1           3386.7            139.0
64x2048                 45.4             41.5             44.1          11084.3           9816.7          16645.5            263.5
64x4096                 86.4             77.6             83.5          47216.2          42726.9          82990.8            519.2

required square
shape                  JVRUST         JVHYBRID            JVCPP              JVX              JVS              JVC            SciPy
16x16                    1.1              1.1              1.1              4.2              1.6              4.2              2.4
32x32                    2.3              2.2              2.3              5.5              2.9              8.1              8.5
64x64                   15.9             15.3             16.0             23.8             19.8             49.5             52.5
128x128                  74.1             72.2             75.0            167.1            165.1            264.0            245.9
256x256                 220.0            218.2            230.2            368.3            364.5            987.2           1057.1
512x512                1035.5           1034.4           1107.1           3461.5           3458.1           5382.5           4775.8
1024x1024               4248.9           4274.7           4525.3          13312.4          13272.6          20411.5          23080.2

required wide
shape                  JVRUST         JVHYBRID            JVCPP              JVX              JVS              JVC            SciPy
16x64                    1.1              1.0              1.1             12.1             13.7             17.2              3.9
32x128                   3.1              2.8              3.3             33.3             34.4             96.3             11.9
64x256                  10.4              9.9             10.6            113.3            108.9            399.9             43.4
128x512                  36.6             33.7             36.7            430.6            401.3           3956.7            196.8
256x1024                117.2            107.1            115.8           1645.4           1528.6          21653.8            702.3
512x2048                447.9            415.9            444.0           9401.9           8432.4         181064.6           2967.7

Results saved: <benchmark>/runs/full-linux-p314-20261029/scaling
== extended: run.py --output <output>/extended --cpu 0
Plan: 132 timing cases, 405 fresh-process memory trials
Timing 1/132: 000_large_square_required_1000x1000
Timing 2/132: 001_large_square_optional_1000x1000
Timing 3/132: 002_large_square_required_2000x2000
Timing 4/132: 003_large_square_optional_2000x2000
Timing 5/132: 004_large_square_required_3000x3000
Timing 6/132: 005_large_square_optional_3000x3000
Timing 7/132: 006_large_square_required_5000x5000
Timing 8/132: 007_large_square_optional_5000x5000
Timing 9/132: 008_large_rectangle_required_1000x2000
Timing 10/132: 009_large_rectangle_optional_1000x2000
Timing 11/132: 010_large_rectangle_required_2000x1000
Timing 12/132: 011_large_rectangle_optional_2000x1000
Timing 13/132: 012_large_rectangle_required_2000x3000
Timing 14/132: 013_large_rectangle_optional_2000x3000
Timing 15/132: 014_large_rectangle_required_3000x2000
Timing 16/132: 015_large_rectangle_optional_3000x2000
Timing 17/132: 016_large_rectangle_required_4000x5000
Timing 18/132: 017_large_rectangle_optional_4000x5000
Timing 19/132: 018_large_rectangle_required_5000x4000
Timing 20/132: 019_large_rectangle_optional_5000x4000
Timing 21/132: 020_extreme_rectangle_required_64x4096
Timing 22/132: 021_extreme_rectangle_optional_64x4096
Timing 23/132: 022_extreme_rectangle_required_4096x64
Timing 24/132: 023_extreme_rectangle_optional_4096x64
Timing 25/132: 024_extreme_rectangle_required_64x8192
Timing 26/132: 025_extreme_rectangle_optional_64x8192
Timing 27/132: 026_extreme_rectangle_required_8192x64
Timing 28/132: 027_extreme_rectangle_optional_8192x64
Timing 29/132: 028_extreme_rectangle_required_64x16384
Timing 30/132: 029_extreme_rectangle_optional_64x16384
Timing 31/132: 030_extreme_rectangle_required_16384x64
Timing 32/132: 031_extreme_rectangle_optional_16384x64
Timing 33/132: 032_congestion_required_256x320
Timing 34/132: 033_congestion_optional_256x320
Timing 35/132: 034_congestion_required_256x320
Timing 36/132: 035_congestion_optional_256x320
Timing 37/132: 036_congestion_required_256x320
Timing 38/132: 037_congestion_optional_256x320
Timing 39/132: 038_congestion_required_256x320
Timing 40/132: 039_congestion_optional_256x320
Timing 41/132: 040_congestion_required_256x320
Timing 42/132: 041_congestion_optional_256x320
Timing 43/132: 042_forbidden_required_256x320
Timing 44/132: 043_forbidden_optional_256x320
Timing 45/132: 044_forbidden_required_256x320
Timing 46/132: 045_forbidden_optional_256x320
Timing 47/132: 046_forbidden_required_256x320
Timing 48/132: 047_forbidden_optional_256x320
Timing 49/132: 048_forbidden_required_256x320
Timing 50/132: 049_forbidden_optional_256x320
Timing 51/132: 050_ties_required_256x320
Timing 52/132: 051_ties_optional_256x320
Timing 53/132: 052_ties_required_256x320
Timing 54/132: 053_ties_optional_256x320
Timing 55/132: 054_ties_required_256x320
Timing 56/132: 055_ties_optional_256x320
Timing 57/132: 056_ties_required_256x320
Timing 58/132: 057_ties_optional_256x320
Timing 59/132: 058_congestion_required_512x640
Timing 60/132: 059_congestion_optional_512x640
Timing 61/132: 060_congestion_required_512x640
Timing 62/132: 061_congestion_optional_512x640
Timing 63/132: 062_congestion_required_512x640
Timing 64/132: 063_congestion_optional_512x640
Timing 65/132: 064_congestion_required_512x640
Timing 66/132: 065_congestion_optional_512x640
Timing 67/132: 066_congestion_required_512x640
Timing 68/132: 067_congestion_optional_512x640
Timing 69/132: 068_forbidden_required_512x640
Timing 70/132: 069_forbidden_optional_512x640
Timing 71/132: 070_forbidden_required_512x640
Timing 72/132: 071_forbidden_optional_512x640
Timing 73/132: 072_forbidden_required_512x640
Timing 74/132: 073_forbidden_optional_512x640
Timing 75/132: 074_forbidden_required_512x640
Timing 76/132: 075_forbidden_optional_512x640
Timing 77/132: 076_ties_required_512x640
Timing 78/132: 077_ties_optional_512x640
Timing 79/132: 078_ties_required_512x640
Timing 80/132: 079_ties_optional_512x640
Timing 81/132: 080_ties_required_512x640
Timing 82/132: 081_ties_optional_512x640
Timing 83/132: 082_ties_required_512x640
Timing 84/132: 083_ties_optional_512x640
Timing 85/132: 084_signed_required_256x320
Timing 86/132: 085_signed_optional_256x320
Timing 87/132: 086_signed_required_320x256
Timing 88/132: 087_signed_optional_320x256
Timing 89/132: 088_rejection_optional_128x160
Timing 90/132: 089_rejection_optional_128x160
Timing 91/132: 090_rejection_optional_128x160
Timing 92/132: 091_rejection_optional_128x160
Timing 93/132: 092_rejection_optional_128x160
Timing 94/132: 093_rejection_optional_128x160
Timing 95/132: 094_rejection_optional_128x160
Timing 96/132: 095_rejection_optional_128x160
Timing 97/132: 096_rejection_optional_128x160
Timing 98/132: 097_rejection_optional_128x160
Timing 99/132: 098_rejection_optional_128x160
Timing 100/132: 099_rejection_optional_128x160
Timing 101/132: 100_rejection_optional_128x160
Timing 102/132: 101_rejection_optional_128x160
Timing 103/132: 102_rejection_optional_128x160
Timing 104/132: 103_rejection_optional_128x160
Timing 105/132: 104_rejection_optional_128x160
Timing 106/132: 105_rejection_optional_128x160
Timing 107/132: 106_rejection_optional_128x160
Timing 108/132: 107_rejection_optional_128x160
Timing 109/132: 108_rejection_optional_128x160
Timing 110/132: 109_rejection_optional_128x160
Timing 111/132: 110_rejection_optional_256x320
Timing 112/132: 111_rejection_optional_256x320
Timing 113/132: 112_rejection_optional_256x320
Timing 114/132: 113_rejection_optional_256x320
Timing 115/132: 114_rejection_optional_256x320
Timing 116/132: 115_rejection_optional_256x320
Timing 117/132: 116_rejection_optional_256x320
Timing 118/132: 117_rejection_optional_256x320
Timing 119/132: 118_rejection_optional_256x320
Timing 120/132: 119_rejection_optional_256x320
Timing 121/132: 120_rejection_optional_256x320
Timing 122/132: 121_rejection_optional_256x320
Timing 123/132: 122_rejection_optional_256x320
Timing 124/132: 123_rejection_optional_256x320
Timing 125/132: 124_rejection_optional_256x320
Timing 126/132: 125_rejection_optional_256x320
Timing 127/132: 126_rejection_optional_256x320
Timing 128/132: 127_rejection_optional_256x320
Timing 129/132: 128_rejection_optional_256x320
Timing 130/132: 129_rejection_optional_256x320
Timing 131/132: 130_rejection_optional_256x320
Timing 132/132: 131_rejection_optional_256x320
Memory 1/405: memory_required_256x256 jvrust
Memory 6/405: memory_required_256x256 jvcpp
Memory 11/405: memory_required_256x256 scipy
Memory 16/405: memory_required_256x256 jvx
Memory 21/405: memory_optional_256x256 jvrust
Memory 26/405: memory_optional_256x256 jvcpp
Memory 31/405: memory_optional_256x256 scipy_capped
Memory 36/405: memory_optional_256x256 scipy_dummies
Memory 41/405: memory_optional_256x256 scipy_square
Memory 46/405: memory_required_256x512 jvrust
Memory 51/405: memory_required_256x512 jvcpp
Memory 56/405: memory_required_256x512 scipy
Memory 61/405: memory_required_256x512 jvx
Memory 66/405: memory_optional_256x512 jvrust
Memory 71/405: memory_optional_256x512 jvcpp
Memory 76/405: memory_optional_256x512 scipy_capped
Memory 81/405: memory_optional_256x512 scipy_dummies
Memory 86/405: memory_optional_256x512 scipy_square
Memory 91/405: memory_required_512x256 jvrust
Memory 96/405: memory_required_512x256 jvcpp
Memory 101/405: memory_required_512x256 scipy
Memory 106/405: memory_required_512x256 jvx
Memory 111/405: memory_optional_512x256 jvrust
Memory 116/405: memory_optional_512x256 jvcpp
Memory 121/405: memory_optional_512x256 scipy_capped
Memory 126/405: memory_optional_512x256 scipy_dummies
Memory 131/405: memory_optional_512x256 scipy_square
Memory 136/405: memory_required_256x1024 jvrust
Memory 141/405: memory_required_256x1024 jvcpp
Memory 146/405: memory_required_256x1024 scipy
Memory 151/405: memory_required_256x1024 jvx
Memory 156/405: memory_optional_256x1024 jvrust
Memory 161/405: memory_optional_256x1024 jvcpp
Memory 166/405: memory_optional_256x1024 scipy_capped
Memory 171/405: memory_optional_256x1024 scipy_dummies
Memory 176/405: memory_optional_256x1024 scipy_square
Memory 181/405: memory_required_1024x256 jvrust
Memory 186/405: memory_required_1024x256 jvcpp
Memory 191/405: memory_required_1024x256 scipy
Memory 196/405: memory_required_1024x256 jvx
Memory 201/405: memory_optional_1024x256 jvrust
Memory 206/405: memory_optional_1024x256 jvcpp
Memory 211/405: memory_optional_1024x256 scipy_capped
Memory 216/405: memory_optional_1024x256 scipy_dummies
Memory 221/405: memory_optional_1024x256 scipy_square
Memory 226/405: memory_required_256x2048 jvrust
Memory 231/405: memory_required_256x2048 jvcpp
Memory 236/405: memory_required_256x2048 scipy
Memory 241/405: memory_required_256x2048 jvx
Memory 246/405: memory_optional_256x2048 jvrust
Memory 251/405: memory_optional_256x2048 jvcpp
Memory 256/405: memory_optional_256x2048 scipy_capped
Memory 261/405: memory_optional_256x2048 scipy_dummies
Memory 266/405: memory_optional_256x2048 scipy_square
Memory 271/405: memory_required_2048x256 jvrust
Memory 276/405: memory_required_2048x256 jvcpp
Memory 281/405: memory_required_2048x256 scipy
Memory 286/405: memory_required_2048x256 jvx
Memory 291/405: memory_optional_2048x256 jvrust
Memory 296/405: memory_optional_2048x256 jvcpp
Memory 301/405: memory_optional_2048x256 scipy_capped
Memory 306/405: memory_optional_2048x256 scipy_dummies
Memory 311/405: memory_optional_2048x256 scipy_square
Memory 316/405: memory_required_256x4096 jvrust
Memory 321/405: memory_required_256x4096 jvcpp
Memory 326/405: memory_required_256x4096 scipy
Memory 331/405: memory_required_256x4096 jvx
Memory 336/405: memory_optional_256x4096 jvrust
Memory 341/405: memory_optional_256x4096 jvcpp
Memory 346/405: memory_optional_256x4096 scipy_capped
Memory 351/405: memory_optional_256x4096 scipy_dummies
Memory 356/405: memory_optional_256x4096 scipy_square
Memory 361/405: memory_required_4096x256 jvrust
Memory 366/405: memory_required_4096x256 jvcpp
Memory 371/405: memory_required_4096x256 scipy
Memory 376/405: memory_required_4096x256 jvx
Memory 381/405: memory_optional_4096x256 jvrust
Memory 386/405: memory_optional_4096x256 jvcpp
Memory 391/405: memory_optional_4096x256 scipy_capped
Memory 396/405: memory_optional_4096x256 scipy_dummies
Memory 401/405: memory_optional_4096x256 scipy_square

Median milliseconds per matrix; ratio = method / reference (SciPy for R, capped SciPy for F)
000_large_square_required_1000x1000        JVRUST 4.516 (0.21), JVHYBRID 4.544 (0.21), JVCPP 4.775 (0.22), SciPy 21.579 (1.00)
001_large_square_optional_1000x1000        JVRUST 0.364 (0.09), JVCPP 0.343 (0.09), SciPy capped 3.880 (1.00), SciPy dummy cols 7.948 (2.05)
002_large_square_required_2000x2000        JVRUST 23.866 (0.22), JVHYBRID 24.109 (0.22), JVCPP 24.974 (0.23), SciPy 110.609 (1.00)
003_large_square_optional_2000x2000        JVRUST 1.723 (0.11), JVCPP 1.660 (0.10), SciPy capped 15.968 (1.00), SciPy dummy cols 35.672 (2.23)
004_large_square_required_3000x3000        JVRUST 63.798 (0.21), JVHYBRID 63.934 (0.21), JVCPP 65.712 (0.21), SciPy 306.037 (1.00)
005_large_square_optional_3000x3000        JVRUST 3.848 (0.09), JVCPP 3.713 (0.09), SciPy capped 41.080 (1.00), SciPy dummy cols 80.711 (1.96)
006_large_square_required_5000x5000        JVRUST 250.186 (0.24), JVHYBRID 250.435 (0.24), JVCPP 254.317 (0.24), SciPy 1044.099 (1.00)
007_large_square_optional_5000x5000        JVRUST 10.845 (0.09), JVCPP 10.570 (0.08), SciPy capped 126.932 (1.00), SciPy dummy cols 224.285 (1.77)
008_large_rectangle_required_1000x2000     JVRUST 1.069 (0.14), JVHYBRID 1.012 (0.13), JVCPP 1.070 (0.14), SciPy 7.896 (1.00)
009_large_rectangle_optional_1000x2000     JVRUST 0.721 (0.12), JVCPP 0.700 (0.11), SciPy capped 6.201 (1.00), SciPy dummy cols 9.512 (1.53)
010_large_rectangle_required_2000x1000     JVRUST 2.348 (0.23), JVHYBRID 2.286 (0.23), JVCPP 2.170 (0.22), SciPy 10.033 (1.00)
011_large_rectangle_optional_2000x1000     JVRUST 1.981 (0.22), JVCPP 1.771 (0.19), SciPy capped 9.112 (1.00), SciPy dummy cols 10.174 (1.12)
012_large_rectangle_required_2000x3000     JVRUST 3.610 (0.12), JVHYBRID 3.436 (0.11), JVCPP 3.577 (0.12), SciPy 30.735 (1.00)
013_large_rectangle_optional_2000x3000     JVRUST 2.299 (0.10), JVCPP 2.223 (0.09), SciPy capped 23.483 (1.00), SciPy dummy cols 39.597 (1.69)
014_large_rectangle_required_3000x2000     JVRUST 17.018 (0.36), JVHYBRID 16.900 (0.36), JVCPP 16.563 (0.35), SciPy 47.222 (1.00)
015_large_rectangle_optional_3000x2000     JVRUST 15.732 (0.38), JVCPP 15.201 (0.36), SciPy capped 41.677 (1.00), SciPy dummy cols 43.004 (1.03)
016_large_rectangle_required_4000x5000     JVRUST 15.122 (0.11), JVHYBRID 14.406 (0.11), JVCPP 14.886 (0.11), SciPy 131.594 (1.00)
017_large_rectangle_optional_4000x5000     JVRUST 8.113 (0.09), JVCPP 7.888 (0.09), SciPy capped 91.464 (1.00), SciPy dummy cols 150.795 (1.65)
018_large_rectangle_required_5000x4000     JVRUST 60.978 (0.28), JVHYBRID 60.414 (0.28), JVCPP 60.893 (0.28), SciPy 214.789 (1.00)
019_large_rectangle_optional_5000x4000     JVRUST 54.344 (0.31), JVCPP 54.392 (0.31), SciPy capped 174.812 (1.00), SciPy dummy cols 162.867 (0.93)
020_extreme_rectangle_required_64x4096     JVRUST 0.085 (0.16), JVHYBRID 0.077 (0.15), JVCPP 0.082 (0.16), SciPy 0.520 (1.00)
021_extreme_rectangle_optional_64x4096     JVRUST 0.058 (0.10), JVCPP 0.054 (0.09), SciPy capped 0.590 (1.00), SciPy dummy cols 0.585 (0.99)
022_extreme_rectangle_required_4096x64     JVRUST 0.206 (0.20), JVHYBRID 0.197 (0.19), JVCPP 0.581 (0.56), SciPy 1.045 (1.00)
023_extreme_rectangle_optional_4096x64     JVRUST 0.178 (0.10), JVCPP 0.550 (0.32), SciPy capped 1.700 (1.00), SciPy dummy cols 0.788 (0.46)
024_extreme_rectangle_required_64x8192     JVRUST 0.168 (0.16), JVHYBRID 0.151 (0.15), JVCPP 0.167 (0.16), SciPy 1.027 (1.00)
025_extreme_rectangle_optional_64x8192     JVRUST 0.121 (0.10), JVCPP 0.111 (0.09), SciPy capped 1.185 (1.00), SciPy dummy cols 1.153 (0.97)
026_extreme_rectangle_required_8192x64     JVRUST 0.416 (0.20), JVHYBRID 0.396 (0.19), JVCPP 1.152 (0.56), SciPy 2.073 (1.00)
027_extreme_rectangle_optional_8192x64     JVRUST 0.367 (0.11), JVCPP 1.097 (0.33), SciPy capped 3.315 (1.00), SciPy dummy cols 1.878 (0.57)
028_extreme_rectangle_required_64x16384    JVRUST 0.374 (0.18), JVHYBRID 0.345 (0.16), JVCPP 0.364 (0.17), SciPy 2.101 (1.00)
029_extreme_rectangle_optional_64x16384    JVRUST 0.294 (0.12), JVCPP 0.277 (0.11), SciPy capped 2.455 (1.00), SciPy dummy cols 2.341 (0.95)
030_extreme_rectangle_required_16384x64    JVRUST 1.036 (0.25), JVHYBRID 1.016 (0.24), JVCPP 2.316 (0.55), SciPy 4.201 (1.00)
031_extreme_rectangle_optional_16384x64    JVRUST 0.949 (0.14), JVCPP 2.207 (0.33), SciPy capped 6.740 (1.00), SciPy dummy cols 4.127 (0.61)
032_congestion_required_256x320            JVRUST 0.115 (0.21), JVHYBRID 0.106 (0.19), JVCPP 0.115 (0.21), SciPy 0.544 (1.00)
033_congestion_optional_256x320            JVRUST 0.065 (0.13), JVCPP 0.066 (0.14), SciPy capped 0.487 (1.00), SciPy dummy cols 0.781 (1.61)
034_congestion_required_256x320            JVRUST 0.624 (0.51), JVHYBRID 0.619 (0.51), JVCPP 0.645 (0.53), SciPy 1.223 (1.00)
035_congestion_optional_256x320            JVRUST 0.520 (0.68), JVCPP 0.535 (0.70), SciPy capped 0.762 (1.00), SciPy dummy cols 1.409 (1.85)
036_congestion_required_256x320            JVRUST 0.771 (0.58), JVHYBRID 0.772 (0.58), JVCPP 0.804 (0.61), SciPy 1.325 (1.00)
037_congestion_optional_256x320            JVRUST 0.619 (0.80), JVCPP 0.632 (0.81), SciPy capped 0.778 (1.00), SciPy dummy cols 1.478 (1.90)
038_congestion_required_256x320            JVRUST 0.882 (0.63), JVHYBRID 0.879 (0.63), JVCPP 0.927 (0.67), SciPy 1.392 (1.00)
039_congestion_optional_256x320            JVRUST 0.707 (0.90), JVCPP 0.733 (0.93), SciPy capped 0.787 (1.00), SciPy dummy cols 1.546 (1.97)
040_congestion_required_256x320            JVRUST 1.005 (0.71), JVHYBRID 1.000 (0.71), JVCPP 1.058 (0.75), SciPy 1.407 (1.00)
041_congestion_optional_256x320            JVRUST 0.799 (1.01), JVCPP 0.827 (1.04), SciPy capped 0.792 (1.00), SciPy dummy cols 1.587 (2.00)
042_forbidden_required_256x320             JVRUST 0.091 (0.17), JVHYBRID 0.083 (0.15), JVCPP 0.090 (0.17), SciPy 0.543 (1.00)
043_forbidden_optional_256x320             JVRUST 0.027 (0.09), JVCPP 0.027 (0.09), SciPy capped 0.303 (1.00), SciPy dummy cols 0.533 (1.76)
044_forbidden_required_256x320             JVRUST 0.093 (0.12), JVHYBRID 0.086 (0.11), JVCPP 0.093 (0.12), SciPy 0.795 (1.00)
045_forbidden_optional_256x320             JVRUST 0.022 (0.08), JVCPP 0.022 (0.08), SciPy capped 0.277 (1.00), SciPy dummy cols 0.699 (2.52)
046_forbidden_required_256x320             JVRUST 0.090 (0.19), JVHYBRID 0.083 (0.17), JVCPP 0.088 (0.19), SciPy 0.475 (1.00)
047_forbidden_optional_256x320             JVRUST 0.021 (0.08), JVCPP 0.020 (0.08), SciPy capped 0.246 (1.00), SciPy dummy cols 0.426 (1.73)
048_forbidden_required_256x320             JVRUST 0.069 (0.21), JVHYBRID 0.066 (0.20), JVCPP 0.068 (0.20), SciPy 0.333 (1.00)
049_forbidden_optional_256x320             JVRUST 0.020 (0.09), JVCPP 0.019 (0.08), SciPy capped 0.233 (1.00), SciPy dummy cols 0.369 (1.58)
050_ties_required_256x320                  JVRUST 0.033 (0.16), JVHYBRID 0.032 (0.15), JVCPP 0.037 (0.17), SciPy 0.213 (1.00)
051_ties_optional_256x320                  JVRUST 0.028 (0.12), JVCPP 0.027 (0.12), SciPy capped 0.231 (1.00), SciPy dummy cols 0.369 (1.59)
052_ties_required_256x320                  JVRUST 0.037 (0.08), JVHYBRID 0.036 (0.07), JVCPP 0.038 (0.08), SciPy 0.477 (1.00)
053_ties_optional_256x320                  JVRUST 0.032 (0.06), JVCPP 0.031 (0.06), SciPy capped 0.497 (1.00), SciPy dummy cols 0.637 (1.28)
054_ties_required_256x320                  JVRUST 0.044 (0.15), JVHYBRID 0.043 (0.15), JVCPP 0.047 (0.16), SciPy 0.288 (1.00)
055_ties_optional_256x320                  JVRUST 0.036 (0.12), JVCPP 0.036 (0.12), SciPy capped 0.305 (1.00), SciPy dummy cols 0.444 (1.46)
056_ties_required_256x320                  JVRUST 0.111 (0.25), JVHYBRID 0.107 (0.24), JVCPP 0.115 (0.26), SciPy 0.440 (1.00)
057_ties_optional_256x320                  JVRUST 0.098 (0.25), JVCPP 0.099 (0.25), SciPy capped 0.399 (1.00), SciPy dummy cols 0.628 (1.58)
058_congestion_required_512x640            JVRUST 0.355 (0.16), JVHYBRID 0.329 (0.15), JVCPP 0.353 (0.16), SciPy 2.181 (1.00)
059_congestion_optional_512x640            JVRUST 0.219 (0.12), JVCPP 0.217 (0.11), SciPy capped 1.895 (1.00), SciPy dummy cols 3.141 (1.66)
060_congestion_required_512x640            JVRUST 2.355 (0.45), JVHYBRID 2.328 (0.45), JVCPP 2.448 (0.47), SciPy 5.222 (1.00)
061_congestion_optional_512x640            JVRUST 1.939 (0.58), JVCPP 1.998 (0.60), SciPy capped 3.341 (1.00), SciPy dummy cols 6.284 (1.88)
062_congestion_required_512x640            JVRUST 2.965 (0.55), JVHYBRID 2.963 (0.55), JVCPP 3.112 (0.57), SciPy 5.436 (1.00)
063_congestion_optional_512x640            JVRUST 2.453 (0.72), JVCPP 2.537 (0.74), SciPy capped 3.410 (1.00), SciPy dummy cols 6.575 (1.93)
064_congestion_required_512x640            JVRUST 3.545 (0.61), JVHYBRID 3.483 (0.60), JVCPP 3.683 (0.64), SciPy 5.784 (1.00)
065_congestion_optional_512x640            JVRUST 2.778 (0.81), JVCPP 2.871 (0.83), SciPy capped 3.447 (1.00), SciPy dummy cols 6.774 (1.97)
066_congestion_required_512x640            JVRUST 3.837 (0.64), JVHYBRID 3.811 (0.63), JVCPP 4.042 (0.67), SciPy 6.023 (1.00)
067_congestion_optional_512x640            JVRUST 3.257 (0.94), JVCPP 3.362 (0.97), SciPy capped 3.481 (1.00), SciPy dummy cols 6.980 (2.01)
068_forbidden_required_512x640             JVRUST 0.304 (0.13), JVHYBRID 0.282 (0.12), JVCPP 0.303 (0.13), SciPy 2.303 (1.00)
069_forbidden_optional_512x640             JVRUST 0.101 (0.09), JVCPP 0.094 (0.08), SciPy capped 1.149 (1.00), SciPy dummy cols 2.093 (1.82)
070_forbidden_required_512x640             JVRUST 0.299 (0.09), JVHYBRID 0.277 (0.09), JVCPP 0.298 (0.09), SciPy 3.231 (1.00)
071_forbidden_optional_512x640             JVRUST 0.086 (0.08), JVCPP 0.080 (0.08), SciPy capped 1.057 (1.00), SciPy dummy cols 2.777 (2.63)
072_forbidden_required_512x640             JVRUST 0.281 (0.16), JVHYBRID 0.257 (0.14), JVCPP 0.276 (0.15), SciPy 1.791 (1.00)
073_forbidden_optional_512x640             JVRUST 0.076 (0.08), JVCPP 0.070 (0.07), SciPy capped 0.961 (1.00), SciPy dummy cols 1.700 (1.77)
074_forbidden_required_512x640             JVRUST 0.222 (0.18), JVHYBRID 0.199 (0.16), JVCPP 0.208 (0.17), SciPy 1.240 (1.00)
075_forbidden_optional_512x640             JVRUST 0.075 (0.08), JVCPP 0.069 (0.08), SciPy capped 0.912 (1.00), SciPy dummy cols 1.467 (1.61)
076_ties_required_512x640                  JVRUST 0.128 (0.15), JVHYBRID 0.117 (0.14), JVCPP 0.137 (0.17), SciPy 0.825 (1.00)
077_ties_optional_512x640                  JVRUST 0.101 (0.11), JVCPP 0.097 (0.11), SciPy capped 0.905 (1.00), SciPy dummy cols 1.476 (1.63)
078_ties_required_512x640                  JVRUST 0.136 (0.07), JVHYBRID 0.126 (0.07), JVCPP 0.133 (0.07), SciPy 1.890 (1.00)
079_ties_optional_512x640                  JVRUST 0.110 (0.06), JVCPP 0.107 (0.05), SciPy capped 1.974 (1.00), SciPy dummy cols 2.541 (1.29)
080_ties_required_512x640                  JVRUST 0.152 (0.14), JVHYBRID 0.144 (0.13), JVCPP 0.157 (0.14), SciPy 1.127 (1.00)
081_ties_optional_512x640                  JVRUST 0.122 (0.10), JVCPP 0.121 (0.10), SciPy capped 1.208 (1.00), SciPy dummy cols 1.778 (1.47)
082_ties_required_512x640                  JVRUST 0.414 (0.27), JVHYBRID 0.406 (0.27), JVCPP 0.428 (0.28), SciPy 1.515 (1.00)
083_ties_optional_512x640                  JVRUST 0.381 (0.27), JVCPP 0.384 (0.27), SciPy capped 1.432 (1.00), SciPy dummy cols 2.323 (1.62)
084_signed_required_256x320                JVRUST 0.097 (0.12), JVHYBRID 0.090 (0.11), JVCPP 0.097 (0.12), SciPy 0.799 (1.00)
085_signed_optional_256x320                JVRUST 0.064 (0.13), JVCPP 0.066 (0.14), SciPy capped 0.480 (1.00), SciPy dummy cols 1.035 (2.15)
086_signed_required_320x256                JVRUST 0.130 (0.15), JVHYBRID 0.122 (0.14), JVCPP 0.123 (0.14), SciPy 0.899 (1.00)
087_signed_optional_320x256                JVRUST 0.097 (0.17), JVCPP 0.094 (0.16), SciPy capped 0.581 (1.00), SciPy dummy cols 1.059 (1.82)
088_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.062 (1.00), SciPy dummy cols 0.158 (2.54)
089_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.10), SciPy capped 0.063 (1.00), SciPy dummy cols 0.159 (2.51)
090_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.10), SciPy capped 0.064 (1.00), SciPy dummy cols 0.158 (2.49)
091_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.006 (0.10), SciPy capped 0.065 (1.00), SciPy dummy cols 0.161 (2.47)
092_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.007 (0.09), SciPy capped 0.069 (1.00), SciPy dummy cols 0.164 (2.38)
093_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.007 (0.09), SciPy capped 0.074 (1.00), SciPy dummy cols 0.172 (2.33)
094_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.008 (0.09), SciPy capped 0.083 (1.00), SciPy dummy cols 0.190 (2.29)
095_rejection_optional_128x160             JVRUST 0.008 (0.09), JVCPP 0.012 (0.13), SciPy capped 0.095 (1.00), SciPy dummy cols 0.232 (2.43)
096_rejection_optional_128x160             JVRUST 0.011 (0.11), JVCPP 0.015 (0.15), SciPy capped 0.099 (1.00), SciPy dummy cols 0.247 (2.50)
097_rejection_optional_128x160             JVRUST 0.015 (0.12), JVCPP 0.018 (0.15), SciPy capped 0.122 (1.00), SciPy dummy cols 0.249 (2.03)
098_rejection_optional_128x160             JVRUST 0.016 (0.12), JVCPP 0.020 (0.15), SciPy capped 0.136 (1.00), SciPy dummy cols 0.249 (1.84)
099_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.10), SciPy capped 0.062 (1.00), SciPy dummy cols 0.098 (1.57)
100_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.063 (1.00), SciPy dummy cols 0.095 (1.50)
101_rejection_optional_128x160             JVRUST 0.005 (0.09), JVCPP 0.006 (0.10), SciPy capped 0.064 (1.00), SciPy dummy cols 0.095 (1.49)
102_rejection_optional_128x160             JVRUST 0.005 (0.08), JVCPP 0.006 (0.10), SciPy capped 0.065 (1.00), SciPy dummy cols 0.095 (1.47)
103_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.006 (0.09), SciPy capped 0.068 (1.00), SciPy dummy cols 0.098 (1.43)
104_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.007 (0.09), SciPy capped 0.072 (1.00), SciPy dummy cols 0.101 (1.41)
105_rejection_optional_128x160             JVRUST 0.006 (0.08), JVCPP 0.007 (0.09), SciPy capped 0.080 (1.00), SciPy dummy cols 0.117 (1.46)
106_rejection_optional_128x160             JVRUST 0.008 (0.08), JVCPP 0.011 (0.11), SciPy capped 0.098 (1.00), SciPy dummy cols 0.175 (1.79)
107_rejection_optional_128x160             JVRUST 0.021 (0.16), JVCPP 0.022 (0.17), SciPy capped 0.131 (1.00), SciPy dummy cols 0.256 (1.95)
108_rejection_optional_128x160             JVRUST 0.188 (1.03), JVCPP 0.195 (1.06), SciPy capped 0.183 (1.00), SciPy dummy cols 0.342 (1.86)
109_rejection_optional_128x160             JVRUST 0.233 (0.69), JVCPP 0.243 (0.72), SciPy capped 0.335 (1.00), SciPy dummy cols 0.447 (1.33)
110_rejection_optional_256x320             JVRUST 0.020 (0.09), JVCPP 0.019 (0.08), SciPy capped 0.231 (1.00), SciPy dummy cols 0.633 (2.74)
111_rejection_optional_256x320             JVRUST 0.020 (0.08), JVCPP 0.019 (0.08), SciPy capped 0.239 (1.00), SciPy dummy cols 0.637 (2.67)
112_rejection_optional_256x320             JVRUST 0.020 (0.08), JVCPP 0.020 (0.08), SciPy capped 0.242 (1.00), SciPy dummy cols 0.636 (2.62)
113_rejection_optional_256x320             JVRUST 0.021 (0.08), JVCPP 0.020 (0.08), SciPy capped 0.252 (1.00), SciPy dummy cols 0.646 (2.56)
114_rejection_optional_256x320             JVRUST 0.022 (0.08), JVCPP 0.022 (0.08), SciPy capped 0.273 (1.00), SciPy dummy cols 0.682 (2.50)
115_rejection_optional_256x320             JVRUST 0.025 (0.09), JVCPP 0.025 (0.08), SciPy capped 0.297 (1.00), SciPy dummy cols 0.744 (2.51)
116_rejection_optional_256x320             JVRUST 0.037 (0.11), JVCPP 0.036 (0.11), SciPy capped 0.336 (1.00), SciPy dummy cols 0.884 (2.63)
117_rejection_optional_256x320             JVRUST 0.054 (0.14), JVCPP 0.055 (0.14), SciPy capped 0.386 (1.00), SciPy dummy cols 1.061 (2.75)
118_rejection_optional_256x320             JVRUST 0.059 (0.14), JVCPP 0.060 (0.15), SciPy capped 0.411 (1.00), SciPy dummy cols 1.067 (2.60)
119_rejection_optional_256x320             JVRUST 0.068 (0.13), JVCPP 0.070 (0.13), SciPy capped 0.542 (1.00), SciPy dummy cols 1.073 (1.98)
120_rejection_optional_256x320             JVRUST 0.072 (0.12), JVCPP 0.074 (0.12), SciPy capped 0.594 (1.00), SciPy dummy cols 1.072 (1.80)
121_rejection_optional_256x320             JVRUST 0.020 (0.09), JVCPP 0.019 (0.08), SciPy capped 0.231 (1.00), SciPy dummy cols 0.361 (1.57)
122_rejection_optional_256x320             JVRUST 0.020 (0.09), JVCPP 0.020 (0.08), SciPy capped 0.235 (1.00), SciPy dummy cols 0.362 (1.54)
123_rejection_optional_256x320             JVRUST 0.020 (0.09), JVCPP 0.020 (0.08), SciPy capped 0.240 (1.00), SciPy dummy cols 0.364 (1.52)
124_rejection_optional_256x320             JVRUST 0.021 (0.08), JVCPP 0.020 (0.08), SciPy capped 0.248 (1.00), SciPy dummy cols 0.368 (1.49)
125_rejection_optional_256x320             JVRUST 0.022 (0.08), JVCPP 0.021 (0.08), SciPy capped 0.267 (1.00), SciPy dummy cols 0.403 (1.51)
126_rejection_optional_256x320             JVRUST 0.024 (0.08), JVCPP 0.024 (0.08), SciPy capped 0.299 (1.00), SciPy dummy cols 0.488 (1.63)
127_rejection_optional_256x320             JVRUST 0.031 (0.09), JVCPP 0.031 (0.09), SciPy capped 0.336 (1.00), SciPy dummy cols 0.625 (1.86)
128_rejection_optional_256x320             JVRUST 0.070 (0.15), JVCPP 0.067 (0.15), SciPy capped 0.461 (1.00), SciPy dummy cols 1.006 (2.18)
129_rejection_optional_256x320             JVRUST 0.151 (0.22), JVCPP 0.148 (0.21), SciPy capped 0.692 (1.00), SciPy dummy cols 1.437 (2.08)
130_rejection_optional_256x320             JVRUST 0.696 (0.89), JVCPP 0.720 (0.92), SciPy capped 0.785 (1.00), SciPy dummy cols 1.534 (1.95)
131_rejection_optional_256x320             JVRUST 0.869 (0.62), JVCPP 0.902 (0.64), SciPy capped 1.401 (1.00), SciPy dummy cols 1.917 (1.37)
{
  "status": "completed",
  "started_utc": "2026-10-29T17:44:52.998782+00:00",
  "python_executable": "<python>/bin/python",
  "source_sha256": "a3c45d1b3833fe768b49e9c3a0e78199974ffbdf957f403d8e519b097dcab17e",
  "planned_timing_cases": 132,
  "planned_memory_trials": 405,
  "timing_cases": 132,
  "timing_samples": 4752,
  "completed_method_settings": 528,
  "memory_trials": 405,
  "objective_checks": 2112,
  "excluded_method_settings": 0,
  "completed_utc": "2026-10-29T17:53:59.374613+00:00",
  "failures": 0
}
All selected suites completed: <output>
(l31410) ratha@home:/media/ratha/HOT/DEV/projects/lapx_all/new8/lap-paper$ python benchmark/audit_controlled_update.py \
  benchmark/runs/full-linux-p311-20261029 \
  benchmark/runs/full-linux-p314-20261029 \
  --output benchmark/runs/linux-audit-20261029.json
{
  "status": "passed",
  "environments": [
    {
      "status": "passed",
      "result_directory": "/media/ratha/HOT/DEV/projects/lapx_all/new8/lap-paper/benchmark/runs/full-linux-p311-20261029",
      "cases": 204,
      "settings": 994,
      "timing_samples": 8946,
      "memory_observations": 415,
      "memory_summaries_recomputed": 81,
      "numeric_objective_records": 3925,
      "base_enumeration_calls": 16800,
      "base_single_objective_checks": 336,
      "batch_output_checks": 11040,
      "formulation_enumeration_and_targeted_calls": 10520,
      "edge_checks": 129,
      "frozen_input_identities": 1212,
      "input_digests": {
        "single": "605a4fddc780f4f7be52619395830e7906184bffaabbb8b0a137eae132605b95",
        "batch": "2d153f269137aaa93c655092c5f97f3274b36a75f683d263b58172125805a292",
        "formulations": "db48a7d60d31cf6f6a8151cc49c211fb4ecb009e68c94cfb6ebc301913f2c095",
        "scaling": "016640124330696fd46ac68c08040e4fbb16790a85c7194697e0eca4bc0a7c72",
        "extended_timing": "33a83919da40b5503bcfe61baa9def3859690ceb7f0db7c0f1d9d32f179402c8",
        "extended_memory": "5ab6c267f46e4627130aa97bf51ece7c63db72c96a424b1bd257883b36ea6842"
      },
      "tables": {
        "base/single": {
          "cases": 12,
          "settings": 84,
          "samples": 756
        },
        "base/batch": {
          "cases": 3,
          "settings": 30,
          "samples": 270
        },
        "formulations": {
          "cases": 10,
          "settings": 50,
          "samples": 450
        },
        "scaling": {
          "cases": 47,
          "settings": 302,
          "samples": 2718
        },
        "extended": {
          "cases": 132,
          "settings": 528,
          "samples": 4752
        }
      },
      "python": "3.11.18 (main, Oct 26 2026, 18:19:35) [GCC 14.3.0]",
      "numpy": "2.4.6",
      "scipy": "1.17.1",
      "packages": {
        "lapx": "0.13.0",
        "lapcpp": "1.2.0",
        "laprust": "1.2.0"
      },
      "native_modules": {
        "laprust._lapjv": {
          "path": "<site-packages>/laprust/_lapjv.cpython-311-x86_64-linux-gnu.so",
          "sha256": "95d6dfa6bd35eee8926ffcc6fefe03424c3a5261ba3d30e43596e05cb8e929c3"
        },
        "lapcpp._lapjv": {
          "path": "<site-packages>/lapcpp/_lapjv.cpython-311-x86_64-linux-gnu.so",
          "sha256": "46d7c9af643eda6f33e470f0a199fcea1416ca2573745ec89fbfbb54568cc60f"
        },
        "lap._lapjv_rh": {
          "path": "<site-packages>/lap/_lapjv_rh.cpython-311-x86_64-linux-gnu.so",
          "sha256": "6f4308da31dc50cecde76f98c0c79f3b56d92a3cb1e5500b3407921433b58901"
        },
        "lap._lapjv": {
          "path": "<site-packages>/lap/_lapjv.cpython-311-x86_64-linux-gnu.so",
          "sha256": "a5286676d1414aa49a81dfc4dd5621e2650a7aad378c95d134a9e40372e05a18"
        },
        "lap._lapjvx": {
          "path": "<site-packages>/lap/_lapjvx.cpython-311-x86_64-linux-gnu.so",
          "sha256": "cd8d3fe3465e06445b514f536c83766e9181311c997fe2885411aba5e5246a08"
        },
        "lap._lapjvs": {
          "path": "<site-packages>/lap/_lapjvs.cpython-311-x86_64-linux-gnu.so",
          "sha256": "c49de60f9b962102b93ebcf296ad435bb8c2d3252618ff1a7e8ae511865453dd"
        },
        "lap._lapjvc": {
          "path": "<site-packages>/lap/_lapjvc.cpython-311-x86_64-linux-gnu.so",
          "sha256": "3ed8c8d496a00341a418de61dcbd0d8e81fd63a815cd982004bf52e4318c57a8"
        }
      },
      "affinity": {
        "single_affinity": [
          0
        ],
        "batch_affinity": [
          0,
          2,
          4,
          6
        ]
      },
      "scope": "Saved-data consistency and arithmetic audit, not an independent re-solve or universal correctness proof."
    },
    {
      "status": "passed",
      "result_directory": "/media/ratha/HOT/DEV/projects/lapx_all/new8/lap-paper/benchmark/runs/full-linux-p314-20261029",
      "cases": 204,
      "settings": 994,
      "timing_samples": 8946,
      "memory_observations": 415,
      "memory_summaries_recomputed": 81,
      "numeric_objective_records": 3925,
      "base_enumeration_calls": 16800,
      "base_single_objective_checks": 336,
      "batch_output_checks": 11040,
      "formulation_enumeration_and_targeted_calls": 10520,
      "edge_checks": 129,
      "frozen_input_identities": 1212,
      "input_digests": {
        "single": "605a4fddc780f4f7be52619395830e7906184bffaabbb8b0a137eae132605b95",
        "batch": "2d153f269137aaa93c655092c5f97f3274b36a75f683d263b58172125805a292",
        "formulations": "db48a7d60d31cf6f6a8151cc49c211fb4ecb009e68c94cfb6ebc301913f2c095",
        "scaling": "016640124330696fd46ac68c08040e4fbb16790a85c7194697e0eca4bc0a7c72",
        "extended_timing": "33a83919da40b5503bcfe61baa9def3859690ceb7f0db7c0f1d9d32f179402c8",
        "extended_memory": "5ab6c267f46e4627130aa97bf51ece7c63db72c96a424b1bd257883b36ea6842"
      },
      "tables": {
        "base/single": {
          "cases": 12,
          "settings": 84,
          "samples": 756
        },
        "base/batch": {
          "cases": 3,
          "settings": 30,
          "samples": 270
        },
        "formulations": {
          "cases": 10,
          "settings": 50,
          "samples": 450
        },
        "scaling": {
          "cases": 47,
          "settings": 302,
          "samples": 2718
        },
        "extended": {
          "cases": 132,
          "settings": 528,
          "samples": 4752
        }
      },
      "python": "3.14.10 | packaged by Anaconda, Inc. | (main, Oct 27 2026, 01:15:40) [GCC 14.3.0]",
      "numpy": "2.5.4",
      "scipy": "1.18.1",
      "packages": {
        "lapx": "0.13.0",
        "lapcpp": "1.2.0",
        "laprust": "1.2.0"
      },
      "native_modules": {
        "laprust._lapjv": {
          "path": "<site-packages>/laprust/_lapjv.cpython-314-x86_64-linux-gnu.so",
          "sha256": "70e54c620bed4bbe783067d51811cfd74fc97c4d51dd3e8004cf0a99f77198e0"
        },
        "lapcpp._lapjv": {
          "path": "<site-packages>/lapcpp/_lapjv.cpython-314-x86_64-linux-gnu.so",
          "sha256": "6965979b4f26ba72a63dcf872b6a2fdb175e9ffa5a027137fbf6b70f9c8bc4dc"
        },
        "lap._lapjv_rh": {
          "path": "<site-packages>/lap/_lapjv_rh.cpython-314-x86_64-linux-gnu.so",
          "sha256": "0769a355f9d8cabf10a41f0da688e20de285e547fafc26271118daf2c9668679"
        },
        "lap._lapjv": {
          "path": "<site-packages>/lap/_lapjv.cpython-314-x86_64-linux-gnu.so",
          "sha256": "ba32a61bfcc85061435f352f7d71358423be7ac463ae2935c4ee74c15d2acd59"
        },
        "lap._lapjvx": {
          "path": "<site-packages>/lap/_lapjvx.cpython-314-x86_64-linux-gnu.so",
          "sha256": "453ed5c0373124cd3a202b06fe0594a408a772221cc0f22348899f7409e51431"
        },
        "lap._lapjvs": {
          "path": "<site-packages>/lap/_lapjvs.cpython-314-x86_64-linux-gnu.so",
          "sha256": "39337d4c0b08b55c213a9b7e30801d49bf8830e767114a3257acb1397b6fbf2f"
        },
        "lap._lapjvc": {
          "path": "<site-packages>/lap/_lapjvc.cpython-314-x86_64-linux-gnu.so",
          "sha256": "36141e98206298dad4d2a5034c4ecb8c38cae444af8168d8299ff556d63a4e7b"
        }
      },
      "affinity": {
        "single_affinity": [
          0
        ],
        "batch_affinity": [
          0,
          2,
          4,
          6
        ]
      },
      "scope": "Saved-data consistency and arithmetic audit, not an independent re-solve or universal correctness proof."
    }
  ],
  "cross_environment": {
    "numeric_objectives_compared": 3925,
    "exact_objective_agreements": 3925,
    "nonzero_differences": [],
    "maximum_absolute_objective_difference": 0,
    "recorded_cardinality_differences": 0,
    "cardinality_policy": "Differences are descriptive, not failures when objectives agree under ties.",
    "same_schedules": true,
    "same_frozen_input_digests": true
  }
}
(l31410) ratha@home:/media/ratha/HOT/DEV/projects/lapx_all/new8/lap-paper$ 

