"""Run the two authorized campaigns sequentially after both preflights pass."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BENCH = ROOT.parent.parent
WORKSPACE = BENCH.parent.parent
STATUS = ROOT / "campaign-status.json"

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(value):
    temporary = STATUS.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(STATUS)

def main():
    assert not STATUS.exists(), "Preserve the existing campaign status"
    assert json.loads((ROOT / "py311-preflight/preflight.json").read_text())["status"] == "passed"
    assert json.loads((ROOT / "py314-preflight/preflight-final.json").read_text())["status"] == "passed"
    source_paths = [BENCH / "run_all.py", *[BENCH / name / "run.py"
                    for name in ("base", "formulations", "scaling", "extended")]]
    sources = {str(p.relative_to(BENCH)): sha(p) for p in source_paths}
    repositories = {}
    for name in ("lap-paper", "lapx", "laprust", "lapcpp"):
        repositories[name] = {
            "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=WORKSPACE / name, text=True).strip(),
            "status": subprocess.check_output(["git", "status", "--porcelain"], cwd=WORKSPACE / name, text=True).strip()}
    state = {"status": "running", "started_utc": utc(), "scope": "Four controlled suites per interpreter",
             "order": ["py311", "py314"], "single_cpu": 0, "batch_cpus": [0, 1, 2, 3],
             "sources": sources, "repositories": repositories, "environments": []}
    save(state)
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    env.pop("PYTHONPATH", None)
    try:
        for name in state["order"]:
            for path in source_paths:
                assert sha(path) == sources[str(path.relative_to(BENCH))], path
            python = ROOT / "envs" / name / "Scripts/python.exe"
            output = ROOT / f"{name}-results"
            assert not output.exists(), output
            command = [str(python), "-B", "-u", str(BENCH / "run_all.py"), "--output", str(output),
                       "--cpu", "0", "--batch-cpus", "0", "1", "2", "3"]
            entry = {"environment": name, "started_utc": utc(), "status": "running",
                     "command": command, "output": str(output)}
            state["environments"].append(entry)
            save(state)
            print(utc(), name, "MEASUREMENTS STARTED", flush=True)
            with (ROOT / f"{name}-measurements.log").open("w", encoding="utf-8") as log:
                result = subprocess.run(command, cwd=BENCH, env=env, stdout=log, stderr=subprocess.STDOUT)
            entry["exit_code"] = result.returncode
            entry["completed_utc"] = utc()
            if result.returncode:
                entry["status"] = "failed"
                raise RuntimeError(f"{name} exited {result.returncode}; inspect its saved log")
            launch = json.loads((output / "run_all.json").read_text())
            assert launch["status"] == "completed" and not launch["smoke"], name
            assert len(launch["suites"]) == 4
            with (ROOT / f"{name}-audit.log").open("w", encoding="utf-8") as log:
                audit = subprocess.run([str(python), "-B", str(ROOT / "audit_campaign.py"),
                    str(output), "--output", str(ROOT / f"{name}-audit.json")],
                    cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            entry["audit_exit_code"] = audit.returncode
            if audit.returncode:
                entry["status"] = "audit_failed"
                raise RuntimeError(f"{name} independent audit failed; inspect its saved log")
            entry["status"] = "completed"
            save(state)
            print(utc(), name, "MEASUREMENTS COMPLETED", flush=True)
        for path in source_paths:
            assert sha(path) == sources[str(path.relative_to(BENCH))], path
        audit_command = [str(python), "-B", str(ROOT / "audit_campaign.py"),
                         str(ROOT / "py311-results"), str(ROOT / "py314-results"),
                         "--output", str(ROOT / "audit.json")]
        with (ROOT / "audit.log").open("w", encoding="utf-8") as log:
            audit = subprocess.run(audit_command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        if audit.returncode:
            raise RuntimeError("Cross-environment audit failed; inspect audit.log")
        with (ROOT / "summary.log").open("w", encoding="utf-8") as log:
            summary = subprocess.run([str(python), "-B", str(ROOT / "summarize_campaign.py"),
                str(ROOT / "py311-results"), str(ROOT / "py314-results"),
                "--archive", str(BENCH / "results.zip"), "--output", str(ROOT / "summary.json")],
                cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        if summary.returncode:
            raise RuntimeError("Summary generation failed; inspect summary.log")
        state["status"] = "completed"
        state["completed_utc"] = utc()
        save(state)
        print(utc(), "BOTH CAMPAIGNS AND INDEPENDENT AUDITS COMPLETED", flush=True)
    except BaseException as error:
        state["status"] = "failed"
        state["error"] = repr(error)
        state["stopped_utc"] = utc()
        save(state)
        raise

if __name__ == "__main__":
    main()
