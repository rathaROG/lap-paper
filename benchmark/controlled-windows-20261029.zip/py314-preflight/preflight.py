"""Prepare evidence for the Python 3.14.10 benchmark campaign, without full timings."""
from pathlib import Path
import datetime
import hashlib
import importlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[4]
BENCHMARK = HERE.parents[2]
ENVIRONMENT = HERE.parent / "envs" / "py314"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    import numpy as np
    import scipy
    import lap, laprust, lapcpp
    import psutil
    wanted = {"lapx":"0.13.0", "laprust":"1.2.0", "lapcpp":"1.2.0",
              "numpy":"2.5.4", "scipy":"1.18.1", "psutil":"7.2.2", "threadpoolctl":"3.7.0"}
    versions = {name:importlib.metadata.version(name) for name in wanted}
    assert versions == wanted, versions
    assert sys.version_info[:3] == (3,14,10), sys.version
    modules = {}
    for name in ("lap", "laprust", "lapcpp", "numpy", "scipy"):
        module = importlib.import_module(name)
        path = Path(module.__file__).resolve()
        assert path.is_relative_to(ENVIRONMENT.resolve()), (name,path)
        modules[name] = str(path)
    cost = np.array([[1.,2.],[3.,1.]])
    for name in ("lapjvxa", "lapjvsa", "lapjvc"):
        getattr(lap,name)(cost,return_cost=False)
    for name in ("lapjvr", "lapjvh"):
        getattr(lap,name)(cost,return_cost=False,output="pairs")
    for module in (laprust,lapcpp):
        module.lapjv(cost,return_cost=False,output="pairs")
    native = {name:{"path":str(path),"sha256":sha(path)} for name,module in sys.modules.items()
              if (name == "lap" or name.startswith(("lap.","laprust.","lapcpp.")))
              and (path := getattr(module,"__file__",None)) and path.endswith(".pyd")}
    sources = {}
    for repo in ("lap-paper","lapx","laprust","lapcpp"):
        folder=WORKSPACE/repo
        sources[repo] = {"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=folder,text=True).strip(),
                         "status":subprocess.check_output(["git","status","--porcelain"],cwd=folder,text=True)}
    report = {"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "executable":sys.executable,"python":sys.version,"platform":platform.platform(),
              "versions":versions,"module_origins":modules,"native_binaries":native,"sources":sources,
              "logical_cpus":psutil.cpu_count(),"physical_cpus":psutil.cpu_count(logical=False),
              "allowed_cpus":psutil.Process().cpu_affinity(),"smoke_is_publication_measurement":False,
              "benchmark_sources":{str(path.relative_to(BENCHMARK)):sha(path)
                                   for path in [BENCHMARK/"run_all.py",BENCHMARK/"check_consistency.py"]
                                   +[BENCHMARK/suite/"run.py" for suite in ("base","formulations","scaling","extended")]}}
    (HERE/"environment.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    env=os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"]="1"
    checks=[]
    commands=[("consistency",[str(BENCHMARK/"check_consistency.py")])]
    commands += [("inputs-"+suite,[str(BENCHMARK/suite/"run.py"),"--check-inputs"])
                 for suite in ("base","formulations","scaling","extended")]
    for repo in ("lapx","laprust","lapcpp"):
        tests=WORKSPACE/repo/"tests"
        # Pre-import the installed package and expose only the tests directory for
        # LAPX's historical conftest import. Never import solver sources in-tree.
        package="lap" if repo=="lapx" else repo
        code=("import sys,pathlib; import "+package+" as package; "
              "assert pathlib.Path(package.__file__).resolve().is_relative_to(pathlib.Path("+repr(str(ENVIRONMENT))+")); "
              "sys.path.insert(0,"+repr(str(tests))+"); import pytest; "
              "raise SystemExit(pytest.main("+repr([str(tests/"test_float32_working_precision.py"),"-q","--import-mode=importlib","-p","no:cacheprovider"])+"))")
        commands.append(("precision-"+repo,["-c",code]))
    for label,args in commands:
        print("START",label,flush=True)
        with (HERE/(label+".log")).open("w",encoding="utf-8") as log:
            proc=subprocess.run([sys.executable,"-B",*args],cwd=HERE,env=env,stdout=log,stderr=subprocess.STDOUT,text=True)
        checks.append({"name":label,"exit_code":proc.returncode,"log":label+".log"})
        print("END",label,proc.returncode,flush=True)
        report["checks"]=checks
        report["passed"]=all(item["exit_code"]==0 for item in checks)
        (HERE/"readiness.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
        if proc.returncode:
            print((HERE/(label+".log")).read_text(encoding="utf-8"),flush=True)
            raise SystemExit(proc.returncode)
    print("Python 3.14 prerequisites and precision/input checks passed.",flush=True)

if __name__=="__main__":
    main()
