from pathlib import Path
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
WORKSPACE=HERE.parents[4]
BENCHMARK=HERE.parents[2]
env=os.environ.copy()
env["PYTHONDONTWRITEBYTECODE"]="1"
temp=HERE/"temp"
temp.mkdir(exist_ok=True)
env["TEMP"]=env["TMP"]=str(temp)
checks=[]

def run(label,args,cwd=HERE):
    print("START",label,flush=True)
    with (HERE/(label+".log")).open("w",encoding="utf-8") as log:
        proc=subprocess.run([sys.executable,"-B",*args],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,text=True)
    checks.append({"name":label,"exit_code":proc.returncode,"log":label+".log"})
    (HERE/"additional-checks.json").write_text(json.dumps(checks,indent=2)+"\n",encoding="utf-8")
    print("END",label,proc.returncode,flush=True)
    if proc.returncode:
        print((HERE/(label+".log")).read_text(encoding="utf-8"))
        raise SystemExit(proc.returncode)

for package in ("laprust","lapcpp"):
    folder=HERE/("reduction-"+package)
    folder.mkdir(exist_ok=True)
    source=WORKSPACE/"lapcpp"/"tests"/"test_reduction_policy.py"
    (folder/"test_reduction_policy.py").write_bytes(source.read_bytes())
    (folder/"conftest.py").write_text("import pytest\nimport "+package+"\n@pytest.fixture(scope='session')\ndef solver():\n    return "+package+"\n",encoding="utf-8")
    run("reduction-"+package,["-m","pytest",str(folder),"-q","--import-mode=importlib","-p","no:cacheprovider"])

run("harness-tests",["-m","unittest","test_verify_results","test_extended_logs","test_run_all_redaction","test_redaction_regressions","-v"],BENCHMARK)
run("smoke-driver",[str(BENCHMARK/"run_all.py"),"--smoke","--output",str(HERE/"smoke"),"--cpu","0","--batch-cpus","0","1","2","3"])
