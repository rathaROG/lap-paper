import pytest
import lapcpp
@pytest.fixture(scope='session')
def solver():
    return lapcpp
