import pytest
import laprust
@pytest.fixture(scope='session')
def solver():
    return laprust
