"""Verify preservation and package completed observations, excluding environments."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile
import datetime

ROOT = Path(__file__).resolve().parent
BENCH = ROOT.parent.parent
WORKSPACE = BENCH.parent.parent

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    status = json.loads((ROOT / "campaign-status.json").read_text())
    audit = json.loads((ROOT / "audit.json").read_text())
    assert status["status"] == "completed" and audit["status"] == "passed"
    before = json.loads((ROOT / "preservation-before.json").read_text())
    assert sha(BENCH / "results.zip") == before["published_archive"]["sha256"]
    after = {"status": "passed", "published_archive_unchanged": True,
             "system_interpreters": [], "repositories": {}}
    code = ('import sys,importlib.metadata as m,json; print(json.dumps({"executable":sys.executable,'
            '"version":sys.version,"packages":sorted((d.metadata["Name"],d.version) for d in m.distributions())}))')
    for old in before["system_interpreters"]:
        observed = json.loads(subprocess.check_output([old["executable"], "-B", "-c", code], text=True))
        assert observed == old, "System interpreter inventory changed"
        after["system_interpreters"].append(observed)
    for name, expected in status["repositories"].items():
        current = {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=WORKSPACE / name, text=True).strip(),
                   "status": subprocess.check_output(["git", "status", "--porcelain"], cwd=WORKSPACE / name, text=True).strip()}
        assert current == expected, (name, current)
        after["repositories"][name] = current
    snapshot = ROOT / "benchmark-sources"
    snapshot.mkdir(exist_ok=False)
    for name, expected in status["sources"].items():
        source = BENCH / name
        assert sha(source) == expected, name
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    (snapshot / "lsape").mkdir()
    shutil.copy2(BENCH / "lsape/redaction.py", snapshot / "lsape/redaction.py")
    (ROOT / "preservation-after.json").write_text(json.dumps(after, indent=2) + "\n")
    folders = ("py311-results", "py314-results", "py311-setup", "py314-setup", "benchmark-sources")
    files = [p for name in folders for p in (ROOT / name).rglob("*") if p.is_file()]
    for name in ("py311-preflight", "py314-preflight"):
        files.extend(p for p in (ROOT / name).rglob("*") if p.is_file()
                     and "smoke" not in p.relative_to(ROOT / name).parts
                     and "temp" not in p.relative_to(ROOT / name).parts
                     and p.suffix in (".json", ".log", ".xml", ".py"))
    files.extend(p for p in ROOT.iterdir() if p.is_file() and p.suffix in (".py", ".json", ".log")
                 and "selfcheck" not in p.name and p.name not in ("manifest.json", "bundle.json"))
    files = sorted(set(files))
    files = [p for p in files if "__pycache__" not in p.parts and ".pytest_cache" not in p.parts]
    manifest = {"scope": "Two full controlled Windows campaigns; smoke timings excluded",
                "files": {p.relative_to(ROOT).as_posix(): {"bytes": p.stat().st_size, "sha256": sha(p)} for p in files}}
    manifest_path = ROOT / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    files.append(manifest_path)
    destination = ROOT / "controlled-windows-20261029.zip"
    assert not destination.exists()
    with zipfile.ZipFile(destination, "x", zipfile.ZIP_DEFLATED) as archive:
        for p in files:
            archive.write(p, p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        for name, expected in manifest["files"].items():
            data = archive.read(name)
            assert len(data) == expected["bytes"] and hashlib.sha256(data).hexdigest() == expected["sha256"]
    report = {"status": "passed", "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "archive": str(destination), "bytes": destination.stat().st_size, "sha256": sha(destination),
              "members": len(files), "contents_verified": True, "system_interpreters_and_sources_preserved": True}
    (ROOT / "bundle.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()
