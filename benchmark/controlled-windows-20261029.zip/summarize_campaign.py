"""Summarize completed new paper campaigns and optional archived comparisons.

Reads saved records only. Run audit_campaign.py separately before publication.
python summarize_campaign.py py311-results py314-results --archive ../../results.zip --output summary.json
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import io
import json
import math
from pathlib import Path
import statistics
import zipfile


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_csv(path):
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def grouped(records):
    result = defaultdict(dict)
    for row in records:
        case, method = row["case"], row["solver"]
        assert method not in result[case], (case, method)
        value = float(row["median_ns"])
        assert math.isfinite(value) and value > 0
        result[case][method] = value
    return dict(result)


def tables(folder):
    return {
        "single": grouped(read_csv(folder / "base/single_summary.csv")),
        "batch": grouped(read_csv(folder / "base/batch_summary.csv")),
        **{s: grouped(read_csv(folder / s / "summary.csv")) for s in ("formulations", "scaling", "extended")},
    }


def archived_tables(archive, python):
    name = {"3.11": "python-3.11.17-20261026-lapx-0.12.0", "3.14": "python-3.14.9-20261026-lapx-0.12.0"}[python]
    prefix = "collections/" + name + "/"
    paths = {"single": "results/single_summary.csv", "batch": "results/batch_summary.csv",
             "formulations": "results/formulations/summary.csv", "scaling": "results/scaling/summary.csv",
             "extended": "extended/summary.csv"}
    values = {label: grouped(list(csv.DictReader(io.StringIO(archive.read(prefix + path).decode("utf-8-sig")))))
              for label, path in paths.items()}
    environment = json.loads(archive.read(prefix + "results/environment.json"))
    return name, values, environment


def comparisons(data, base_required):
    result = defaultdict(list)
    for table in ("single", "formulations", "scaling", "extended"):
        for case, values in data[table].items():
            if table == "single":
                reference = "scipy"
                category = "ordinary_required" if case in base_required else "expanded_optional"
            elif table == "formulations":
                reference, category = "scipy_capped", "capped_optional"
            elif "scipy" in values:
                reference, category = "scipy", "ordinary_required"
            else:
                reference, category = "scipy_capped", "capped_optional"
            for method in ("jvrust", "jvcpp"):
                own, ref = values[method], values[reference]
                result[(method, category)].append({"table": table, "case": case, "reference": reference,
                    "native_ms": own / 1e6, "reference_ms": ref / 1e6, "native_over_reference": own / ref,
                    "reference_over_native": ref / own})
    report = {}
    for method in ("jvrust", "jvcpp"):
        report[method] = {}
        for category, expected in (("ordinary_required", 71), ("capped_optional", 125), ("expanded_optional", 5)):
            records = result[(method, category)]
            assert len(records) == expected, (method, category, len(records))
            report[method][category] = {
                "cases": len(records), "native_faster": sum(r["native_over_reference"] < 1 for r in records),
                "native_slower": sum(r["native_over_reference"] > 1 for r in records),
                "equal_medians": sum(r["native_over_reference"] == 1 for r in records),
                "median_reference_over_native": statistics.median(r["reference_over_native"] for r in records),
                "largest_native_over_reference": max(r["native_over_reference"] for r in records),
                "slowest_relative_cases": sorted(records, key=lambda r: -r["native_over_reference"])[:5],
            }
    return report


def batch_report(data):
    return {case: {method: {"loop_ms": times["jvrust_loop"] / 1e6,
                "one_worker_ms": times[method + "_batch_t1"] / 1e6,
                "four_worker_ms": times[method + "_batch_t4"] / 1e6,
                "rust_loop_over_one_worker": times["jvrust_loop"] / times[method + "_batch_t1"],
                "rust_loop_over_four_worker": times["jvrust_loop"] / times[method + "_batch_t4"],
                "one_over_four_worker": times[method + "_batch_t1"] / times[method + "_batch_t4"]}
            for method in ("jvrust", "jvhybrid", "jvcpp")}
        for case, times in data["batch"].items()}


def historical_comparison(old, new):
    observations = defaultdict(list)
    for table, current_cases in new.items():
        for case, methods in current_cases.items():
            for method, current in methods.items():
                previous = old[table].get(case, {}).get(method)
                if previous is not None:
                    observations[(table, method)].append(previous / current)
    return {table: {method: {"settings": len(ratios),
                    "new_faster": sum(v > 1 for v in ratios), "new_slower": sum(v < 1 for v in ratios),
                    "median_old_over_new": statistics.median(ratios),
                    "geometric_mean_old_over_new": math.exp(statistics.mean(math.log(v) for v in ratios)),
                    "minimum_old_over_new": min(ratios), "maximum_old_over_new": max(ratios)}
                for (section, method), ratios in observations.items() if section == table}
            for table in new}


def summarize(folder, archive):
    env = read_json(folder / "base/environment.json")
    samples = read_csv(folder / "base/single_samples.csv")
    required = {r["case"] for r in samples if math.isinf(float(r["limit"]))}
    assert len(required) == 7
    data = tables(folder)
    report = {"result_directory": str(folder.resolve()), "python": env["python"],
        "numpy": env["numpy"], "scipy": env["scipy"], "packages": env["packages"],
        "native_vs_scipy": comparisons(data, required), "batch": batch_report(data),
        "single_case_medians_ms": {case: {m: t / 1e6 for m, t in methods.items()}
                                   for case, methods in data["single"].items()},
        "scope": "Ratios of within-run medians on the specified workload grid; descriptive, not population estimates or isolated component effects."}
    if archive is not None:
        version = ".".join(env["python"].split()[0].split(".")[:2])
        name, old, old_env = archived_tables(archive, version)
        report["historical"] = {"collection": name, "python": old_env["python"],
            "numpy": old_env["numpy"], "scipy": old_env["scipy"], "packages": old_env["packages"],
            "warning": "Historical sessions, interpreter patch versions, native binaries and possibly toolchains differ. These are descriptive workload-matched comparisons, not isolated solver-change or interpreter effects.",
            "by_suite_and_method": historical_comparison(old, data),
            "single_case_old_over_new": {case: {method: old["single"][case][method] / value
                for method, value in methods.items()} for case, methods in data["single"].items()}}
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path, nargs="+")
    parser.add_argument("--archive", type=Path)
    parser.add_argument("--output", type=Path)
    options = parser.parse_args()
    archive = zipfile.ZipFile(options.archive) if options.archive else None
    try:
        report = {"environments": [summarize(folder, archive) for folder in options.results]}
    finally:
        if archive:
            archive.close()
    text = json.dumps(report, indent=2) + "\n"
    if options.output:
        options.output.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
