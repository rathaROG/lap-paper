"""Prepare and record preflight checks; smoke timings are not measurements."""
from pathlib import Path
import hashlib
import importlib
import importlib.metadata as metadata
import json
import os
import shutil
import subprocess
import sys
import datetime

ROOT = Path(__file__).resolve().parent
BENCH = ROOT.parent.parent
WORKSPACE = BENCH.parent.parent
OUT = ROOT / "py311-preflight"
OUT.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run(label, arguments, cwd=OUT):
    result = subprocess.run([sys.executable, "-B", *map(str, arguments)], cwd=cwd,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, errors="replace", env={**os.environ,
                            "PYTHONDONTWRITEBYTECODE": "1"})
    (OUT / f"{label}.log").write_text(result.stdout, encoding="utf-8")
    print(label, "exit", result.returncode, flush=True)
    if result.returncode:
        print(result.stdout[-6000:], flush=True)
        raise SystemExit(result.returncode)
    return {"label": label, "exit_code": result.returncode,
            "arguments": list(map(str, arguments)), "log": f"{label}.log"}

import numpy as np
import scipy
import psutil
import lap, laprust, lapcpp

expected = {"lapx": "0.13.0", "laprust": "1.2.0", "lapcpp": "1.2.0",
            "numpy": "2.4.6", "scipy": "1.17.1", "psutil": "7.2.2",
            "threadpoolctl": "3.7.0"}
assert sys.version_info[:3] == (3, 11, 18)
assert sys.prefix != sys.base_prefix
for name, version in expected.items():
    assert metadata.version(name) == version, (name, metadata.version(name))
origins = {}
for name in ("numpy", "scipy", "lap", "laprust", "lapcpp"):
    module = importlib.import_module(name)
    origin = Path(module.__file__).resolve()
    assert origin.is_relative_to(Path(sys.prefix).resolve()), origin
    origins[name] = {"path": str(origin), "sha256": sha(origin)}
spec = importlib.util.spec_from_file_location("paper_base_preflight", BENCH / "base/run.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.initialize()
runtime = base.environment({"purpose": "preflight, not publication measurements"})
assert all("error" not in item for item in runtime["native_modules"].values())
provenance = {"recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "python": sys.version, "executable": sys.executable,
              "base_prefix": sys.base_prefix, "versions": expected, "origins": origins,
              "runtime": runtime,
              "benchmark_sources": {f"{s}/run.py": sha(BENCH / s / "run.py")
                 for s in ("base", "formulations", "scaling", "extended")}}
(OUT / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
freeze = subprocess.check_output([sys.executable, "-m", "pip", "freeze", "--all"], text=True)
(ROOT / "py311-setup/requirements-frozen.txt").write_text(freeze, encoding="utf-8")
records = [run("adapter-consistency", [BENCH / "check_consistency.py"])]
for suite in ("base", "formulations", "scaling", "extended"):
    records.append(run(f"inputs-{suite}", [BENCH / suite / "run.py", "--check-inputs"]))

# Copy only the independent regressions, avoiding source-tree imports and build tests.
tests = OUT / "regressions"
for package in ("lapx", "laprust", "lapcpp"):
    folder = tests / package
    folder.mkdir(parents=True)
    source = WORKSPACE / package / "tests/test_float32_working_precision.py"
    shutil.copy2(source, folder / source.name)
    if package != "lapx":
        shutil.copy2(WORKSPACE / package / "tests/conftest.py", folder / "conftest.py")
        shutil.copy2(WORKSPACE / "lapcpp/tests/test_reduction_policy.py", folder / "test_reduction_policy.py")
    records.append(run(f"regressions-{package}", ["-m", "pytest", "-q", "-p", "no:cacheprovider",
                       "--import-mode=importlib", "--junitxml", OUT / f"regressions-{package}.xml", folder]))
records.append(run("harness-tests", ["-m", "unittest", "discover", "-s", BENCH,
                                     "-p", "test_*.py", "-v"]))
records.append(run("smoke", [BENCH / "run_all.py", "--smoke", "--output", OUT / "smoke",
                             "--cpu", "0", "--batch-cpus", "0", "1", "2", "3"]))
report = {"status": "passed", "smoke_is_publication_measurement": False,
          "python": sys.version, "versions": expected, "checks": records,
          "input_identity_count": 1212}
(OUT / "preflight.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print("PY311 PREFLIGHT PASSED", flush=True)
