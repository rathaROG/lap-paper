"""Saved-data audit for the 2026-10-29 current-package cached tracking campaign.
Derived from the original paper's independent standard-library evidence auditor.
No solver, tracker, measurement module or external dataset is executed.
"""
from __future__ import annotations
import ast, gzip, hashlib, json, math, statistics, struct, zipfile
from collections import Counter, defaultdict
from pathlib import Path, PurePosixPath
class EvidenceError(ValueError): pass
ROOT = Path(__file__).resolve().parents[3]
COLLECTION = "real-world-python-3.11.18-20261029-lapx-0.13.0"
SOLVERS=("lapjv","lapjvx","lapjvxa","lapjvh","laprust","lapcpp","scipy","lapjvs","lapjvc")
SEQUENCES=("mot16_04","mot20_03")
SOURCES=("gt","rfdetr_nano")
TRACKERS=("centroid","sort")
CASES=tuple(f"{seq}_{source}_{tracker}" for seq in SEQUENCES for source in SOURCES for tracker in TRACKERS)
EXPECTED_OBSERVATIONS={"mot16_04_gt":51545,"mot20_03_gt":106637,"mot16_04_rfdetr_nano":30621,"mot20_03_rfdetr_nano":45990}
EXPECTED_CALLS={case:(976 if case=="mot16_04_rfdetr_nano_sort" else 575 if case=="mot20_03_rfdetr_nano_sort" else 998) for case in CASES}
def load_evidence(root):
    folder=Path(root).resolve()
    return {"folder":folder,"summary":read(folder/"summary.json"),
      "inputs":{f.name.removesuffix(".json.gz"):json.loads(gzip.decompress(f.read_bytes())) for f in (ROOT/"benchmark/real_world/data/inputs").glob("*.json.gz")},
      "captures":{case:read(folder/"profiles"/f"{case}__scipy.json") for case in CASES}}
def require(condition, message):
    if not condition:
        raise EvidenceError(message)

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()

def local(root, relative):
    value = PurePosixPath(str(relative).replace("\\", "/"))
    require(not value.is_absolute() and ".." not in value.parts and
            all(":" not in part for part in value.parts), f"Nonlocal evidence path: {relative}")
    result = (root / Path(*value.parts)).resolve()
    require(result.is_relative_to(root.resolve()), f"Evidence path escapes packet: {relative}")
    return result

def close(actual, expected, label, tolerance=1e-12):
    require(isinstance(actual, (int, float)) and math.isfinite(actual) and
            math.isclose(actual, expected, rel_tol=tolerance, abs_tol=tolerance),
            f"{label}: {actual!r} != {expected!r}")

def indexed(rows, keys, label):
    result = {}
    for row in rows:
        key = tuple(row[name] for name in keys)
        require(key not in result, f"Duplicate {label}: {key}")
        result[key] = row
    return result

def quartiles(values):
    """NumPy's default linear percentiles, independently using the stdlib."""
    ordered = sorted(values)
    require(bool(ordered), "Empty timing group")
    def percentile(fraction):
        position = (len(ordered) - 1) * fraction
        lower = math.floor(position)
        upper = math.ceil(position)
        return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)
    return statistics.median(ordered), percentile(.25), percentile(.75)

def prediction_hash(rows):
    return hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def check_inputs(inputs):
    require(set(inputs) == {f"{seq}_{source}" for seq in SEQUENCES for source in SOURCES}, "Real-world input scope differs")
    counts = {}
    for name, cache in inputs.items():
        meta, frames = cache["metadata"], cache["frames"]
        require(name == f"{meta['sequence']}_{meta['source']}", f"Input identity differs: {name}")
        require(meta["frames"] == 999 and [frame["frame"] for frame in frames] == list(range(1, 1000)), f"Input frame coverage differs: {name}")
        require(meta["video"]["decoded_frames"] == 999 and meta["video"]["reported_frames"] == 999 and meta["video"]["fully_decoded"], f"Video coverage differs: {name}")
        close(meta["video"]["fps"], 24., f"{name} video FPS")
        require(meta["frame_mapping"] == "decoded zero-based index k maps to GT frame k+1", f"Input frame mapping differs: {name}")
        require(meta["reference"]["last_frame"] >= 999, f"Reference prefix insufficient: {name}")
        detections, references = 0, 0
        for frame in frames:
            gt, detected = frame["gt"], frame["detections"]
            require(len({obj["id"] for obj in gt}) == len(gt), f"Duplicate reference identity: {name}/{frame['frame']}")
            for det in detected:
                require(set(det) == {"box", "repspoint", "score"}, f"Detection identity/unknown field leakage: {name}/{frame['frame']}")
                require(len(det["box"]) == 4 and all(type(v) is int for v in det["box"]) and
                        det["box"][2] > det["box"][0] and det["box"][3] > det["box"][1], f"Invalid detection box: {name}")
                require(len(det["repspoint"]) == 2 and all(type(v) is int for v in det["repspoint"]), f"Invalid representative point: {name}")
                require(math.isfinite(det["score"]) and 0 <= det["score"] <= 1, f"Invalid confidence: {name}")
            if meta["source"] == "gt":
                require(Counter(tuple(d["box"]) for d in detected) == Counter(tuple(g["box"]) for g in gt), f"GT detections differ from reference geometry: {name}")
                require(all(d["score"] == 1 for d in detected), f"GT confidence differs: {name}")
            else:
                width, height = meta["video"]["width"], meta["video"]["height"]
                require(len(detected) <= 300 and all(0 <= d["box"][0] < d["box"][2] <= width and
                        0 <= d["box"][1] < d["box"][3] <= height and d["box"][2] - d["box"][0] >= 15 and d["score"] >= .2 for d in detected), f"RF filters/cap differ: {name}")
            detections += len(detected)
            references += len(gt)
        require(detections == EXPECTED_OBSERVATIONS[name], f"Detection observation count differs: {name}")
        require(references == EXPECTED_OBSERVATIONS[meta['sequence'] + '_gt'], f"Reference observation count differs: {name}")
        if meta["source"] == "rfdetr_nano":
            detector = meta["detector"]
            settings = detector["settings"]
            for key, expected in {"model_size": "nano", "conf": .2, "imgsz": 768, "person_class_id": 1, "max_det": 300, "min_width_filter": 15, "optimize": True}.items():
                require(settings[key] == expected, f"RF detector setting differs: {name}/{key}")
            resolution = detector["resolution"]
            require(all(resolution[key] == 768 for key in ("requested_imgsz", "effective_config_resolution", "effective_model_resolution", "effective_optimized_resolution")), f"RF runtime resolution differs: {name}")
            require(resolution["observed_input_tensor_shapes"] == [[1, 3, 768, 768]] * 3, f"RF observed shape differs: {name}")
            require(detector["checkpoint"]["matches_published_md5"] and detector["package_version"] == "1.10.1", f"RF checkpoint/version differs: {name}")
        counts[name] = {"reference_observations": references, "detection_observations": detections}
    for sequence in SEQUENCES:
        gt, rf = (inputs[f"{sequence}_{source}"] for source in SOURCES)
        require([f["gt"] for f in gt["frames"]] == [f["gt"] for f in rf["frames"]], f"Reference GT differs between detector sources: {sequence}")
        for key in ("video", "gt", "gt_map"):
            require(gt["metadata"]["inputs"][key]["sha256"] == rf["metadata"]["inputs"][key]["sha256"], f"Input SHA differs between sources: {sequence}/{key}")
    return counts

def check_metric_formulas(metrics, reference_count, predicted_count, label):
    require(metrics["num_frames"] == 999 and metrics["num_objects"] == reference_count and metrics["num_predictions"] == predicted_count, f"Metric coverage differs: {label}")
    true = metrics["num_detections"]
    require(true + metrics["num_misses"] == reference_count and true + metrics["num_false_positives"] == predicted_count, f"Metric count identity differs: {label}")
    require(metrics["idtp"] + metrics["idfn"] == reference_count and metrics["idtp"] + metrics["idfp"] == predicted_count, f"Identity count arithmetic differs: {label}")
    require(metrics["num_matches"] + metrics["num_switches"] == true, f"Match/switch count arithmetic differs: {label}")
    close(metrics["mota"], 1 - (metrics["num_misses"] + metrics["num_false_positives"] + metrics["num_switches"]) / reference_count, label + " MOTA")
    close(metrics["idf1"], 2 * metrics["idtp"] / (2 * metrics["idtp"] + metrics["idfp"] + metrics["idfn"]), label + " IDF1")
    close(metrics["precision"], true / predicted_count, label + " precision")
    close(metrics["recall"], true / reference_count, label + " recall")
    require(metrics["evaluation_assignment_solver"] == "scipy" and metrics["metric_library"] == "motmetrics 1.4.0" and metrics["iou_threshold"] == .5, f"Evaluation definition differs: {label}")

def npy_header(stream):
    require(stream.read(6) == b"\x93NUMPY", "Invalid captured NPY magic")
    version = tuple(stream.read(2))
    require(version in ((1, 0), (2, 0), (3, 0)), f"Unsupported captured NPY version: {version}")
    size = 2 if version == (1, 0) else 4
    length_bytes = stream.read(size)
    require(len(length_bytes) == size, "Truncated NPY header length")
    length = int.from_bytes(length_bytes, "little")
    require(0 < length < 65536, "Unreasonable NPY header length")
    header = ast.literal_eval(stream.read(length).decode("utf-8" if version == (3, 0) else "latin1"))
    require(isinstance(header, dict) and set(header) == {"descr", "fortran_order", "shape"}, "Invalid NPY header fields")
    require(header["descr"] in ("<f4", "=f4") and header["fortran_order"] is False and
            len(header["shape"]) == 2 and all(type(n) is int and n > 0 for n in header["shape"]), "Captured matrix is not contiguous nonempty float32")
    return header, 8 + size + length

def audit_evidence(root=None, *, verify_generated=False, publication=None):
    """Strict saved-data audit; return deterministic counts and provenance hashes."""
    data = load_evidence(root)
    folder, summary = data["folder"], data["summary"]
    manifest = read(folder / "file_manifest.json")
    expected_files = {str(PurePosixPath(key.replace("\\", "/"))) for key in manifest}
    actual_files = {path.relative_to(folder).as_posix() for path in folder.rglob("*") if path.is_file()}
    # The original manifest writer excluded every basename file_manifest.json.
    # The two omitted source-session manifests remain pinned by composition.json.
    origin_manifests = set()
    logical_files = expected_files | {"file_manifest.json"} | origin_manifests
    require(logical_files <= actual_files and actual_files - logical_files <= {"portable_run.json"},
            "Packet file inventory differs from its manifest/composition")
    for relative, record in manifest.items():
        path = local(folder, relative)
        require(path.stat().st_size == record["bytes"] and digest(path) == record["sha256"], f"Packet hash/size differs: {relative}")
    copied_count = 0
    require(summary["environment"]["packages"]["lapx"] == "0.13.0" and summary["environment"]["packages"]["laprust"] == "1.2.0" and summary["environment"]["packages"]["lapcpp"] == "1.2.0", "Unexpected latest solver versions")
    input_counts = check_inputs(data["inputs"])
    protocol = summary["protocol"]
    require(tuple(protocol["solvers"]) == SOLVERS and protocol["rounds"] == 9 and protocol["frames_per_clip"] == 999 and protocol["pipeline_configurations"] == 8, "Real-world protocol scope differs")
    require(protocol["cpu"] == 0 and protocol["library_threads"] == 1 and not protocol["parallel_measurements"] and protocol["tracker_input_precision"] == "float32", "Tracking runtime controls differ")
    tracking = indexed(summary["tracking"], ("case", "solver"), "tracking summary")
    replay = indexed(summary["replay"], ("case", "precision", "solver"), "replay summary")
    require(set(tracking) == {(case, method) for case in CASES for method in SOLVERS}, "Tracking summary coverage differs")
    require(set(replay) == {(case, precision, method) for case in CASES for precision in ("float32", "float64") for method in SOLVERS}, "Replay summary coverage differs")
    raw_samples = read(folder / "tracking_samples.json")
    sample_index = indexed(raw_samples, ("case", "solver", "round"), "tracking sample")
    paths = list((folder / "timing").rglob("*.json"))
    require(len(paths) == 648 and len(raw_samples) == 648, "Expected exactly 648 primary timing files/samples")
    groups = defaultdict(list)
    hashes = defaultdict(set)
    for path in paths:
        row = read(path)
        case, method, round_ = row["case"], row["solver"], row["round"]
        require((case, method) in tracking and row["mode"] == "timed" and row["primary_timing"] and row["frames"] == 999 and row["solver_calls"] is None, f"Primary timing/instrumentation differs: {path.name}")
        require([f["frame"] for f in row["per_frame"]] == list(range(1, 1000)), f"Timed frame coverage differs: {path.name}")
        require(sum(f["tracker_ns"] for f in row["per_frame"]) == row["tracker_total_ns"] and all(f["tracker_ns"] > 0 for f in row["per_frame"]), f"Primary timing sum differs: {path.name}")
        ns = row["tracker_total_ns"] / 999
        sample = sample_index[(case, method, round_)]
        close(sample["nanoseconds"], ns, f"Raw tracking sample {case}/{method}/{round_}")
        require(sample["position"] == row["position"], "Original round position differs")
        groups[case, method].append((round_, ns))
        hashes[case, method].add(row["prediction_sha256"])
    predicted_counts = {}
    for key, row in tracking.items():
        samples = groups[key]
        require(sorted(i for i, _ in samples) == list(range(9)), f"Missing/duplicate primary round: {key}")
        for name, value in zip(("median", "q25", "q75"), quartiles([value for _, value in samples])):
            close(row[f"{name}_tracker_ns_per_frame"], value, f"Tracking {name}: {key}")
        require(hashes[key] == {row["prediction_sha256"]}, f"Repeated trajectories differ: {key}")
        close(row["tracker_fps"], 1e9 / row["median_tracker_ns_per_frame"], f"Tracking FPS: {key}")
        baseline = tracking[key[0], "scipy"]["median_tracker_ns_per_frame"]
        close(row["scipy_speedup"], baseline / row["median_tracker_ns_per_frame"], f"Tracking ratio: {key}")
        predictions = read(folder / "predictions" / f"{key[0]}__{key[1]}.json")["predictions"]
        require(prediction_hash(predictions) == row["prediction_sha256"] and [f["frame"] for f in predictions] == list(range(1, 1000)), f"Saved prediction hash/frames differ: {key}")
        require(all(len({obj["id"] for obj in frame["tracks"]}) == len(frame["tracks"]) for frame in predictions), f"Duplicate predicted CID: {key}")
        predicted_counts[key] = sum(len(frame["tracks"]) for frame in predictions)
        metrics = read(folder / "metrics" / f"{key[0]}__{key[1]}.json")
        reference_count = input_counts[key[0].removesuffix("_" + row["tracker"])]["reference_observations"]
        check_metric_formulas(metrics, reference_count, predicted_counts[key], str(key))
        for name in ("idf1", "mota", "num_switches", "num_false_positives", "num_misses"):
            close(row[name], metrics[name], f"Summary metric {name}: {key}")
    profile_paths = list((folder / "profiles").glob("*.json"))
    require(len(profile_paths) == 80, "Expected 72 logical profiles and eight separate SciPy profiles")
    require({path.name for path in profile_paths} ==
            {f"{case}__{method}.json" for case in CASES for method in SOLVERS} |
            {f"{case}__scipy_without_capture.json" for case in CASES}, "Profile file coverage differs")
    for path in profile_paths:
        row = read(path)
        case = path.name.split("__", 1)[0]
        require(not row["primary_timing"] and row["mode"] in ("capture", "profile") and row["frames"] == 999, f"Profile boundary differs: {path.name}")
        require(row["solver_calls"] == len(row["assignment_calls"]) and
                sum(c["solver_ns"] for c in row["assignment_calls"]) == row["solver_total_ns"] and
                sum(f["solver_calls"] for f in row["per_frame"]) == row["solver_calls"], f"Profile count/timing differs: {path.name}")
        if row["mode"] == "profile":
            saved = tracking[case, row["solver"]]
            close(saved["mean_solver_ns"], row["solver_total_ns"] / row["solver_calls"], f"Profile assignment mean: {path.name}")
            close(saved["solver_fraction_instrumented"], row["solver_total_ns"] / row["tracker_total_ns"], f"Profile instrumented fraction: {path.name}")
    matrix_count = 0
    for case, capture in data["captures"].items():
        records = capture["matrix_metadata"]
        require(capture["mode"] == "capture" and len(records) == EXPECTED_CALLS[case], f"Capture count differs: {case}")
        with zipfile.ZipFile(folder / "matrices" / f"{case}.npz") as archive:
            require(set(archive.namelist()) == {record["key"] + ".npy" for record in records}, f"Captured archive members differ: {case}")
            for number, record in enumerate(records):
                require(record["call_index"] == number and record["source_dtype"] == "float32", f"Capture call index/dtype differs: {case}")
                with archive.open(record["key"] + ".npy") as member:
                    header, prefix = npy_header(member)
                require(list(header["shape"]) == record["shape"], f"NPY matrix shape differs: {case}/{number}")
                require(archive.getinfo(record["key"] + ".npy").file_size == prefix + 4 * math.prod(header["shape"]), f"NPY payload length differs: {case}/{number}")
        matrix_count += len(records)
    require(matrix_count == 7539, "Expected exactly 7,539 captured application matrices")
    replay_paths = list((folder / "replay").glob("*.json"))
    require(len(replay_paths) == 16, "Expected 16 pipeline/precision replay files")
    replay_samples, objective_checks = 0, 0
    for path in replay_paths:
        record = read(path)
        case, precision = record["case"], record["precision"]
        raw = indexed(record["samples"], ("solver", "round"), "replay sample")
        require(set(raw) == {(method, i) for method in SOLVERS for i in range(9)}, f"Replay round coverage differs: {path.name}")
        replay_samples += len(raw)
        require(set(record["validation"]) == set(SOLVERS) | {"lapjvr"}, f"Replay backend/alias validation coverage differs: {path.name}")
        require(record["validation"] == summary["validation"][case][precision], f"Saved replay validation differs from summary: {path.name}")
        for method, check in record["validation"].items():
            require(check["matrices"] == EXPECTED_CALLS[case] and check["objective_max_abs_gap"] == 0 and
                    check["objective_max_gap"] == 0 and check["objective_min_gap"] == 0 and
                    check["objective_nonzero_gap_count"] == 0 and check["objective_mismatch_count"] == 0 and not check["mismatches"], f"Recorded exact objective agreement fails: {path.name}/{method}")
            if method == "lapjvr":
                require(check["laprust_alias_objective_differences"] == 0, f"Alias objective agreement fails: {path.name}")
            objective_checks += check["matrices"]
        for method in SOLVERS:
            saved = replay[case, precision, method]
            values = [raw[method, i]["nanoseconds"] for i in range(9)]
            require(all(raw[method, i]["matrices"] == EXPECTED_CALLS[case] and raw[method, i]["cycles"] >= 1 and values[i] > 0 for i in range(9)), f"Replay workload differs: {path.name}/{method}")
            for name, value in zip(("median", "q25", "q75"), quartiles(values)):
                close(saved[f"{name}_ns_per_assignment"], value, f"Replay {name}: {case}/{precision}/{method}")
            close(saved["scipy_speedup"], replay[case, precision, "scipy"]["median_ns_per_assignment"] / saved["median_ns_per_assignment"], f"Replay ratio: {case}/{precision}/{method}")
    require(replay_samples == 1296 and objective_checks == 150780, "Replay sample/objective-check total differs")
    report = {"status": "passed", "schema_version": 1, "collection": COLLECTION, "collection_manifest_sha256": digest(folder / "file_manifest.json"),
              "summary_sha256": digest(folder / "summary.json"), "input_manifest_sha256": digest(ROOT / "benchmark/real_world/provenance/data_manifest.json"),
              "manifest_files": len(manifest), "verified_origin_copies": copied_count,
              "input_caches": 4, "pipelines": 8, "timed_methods": 9, "rounds": 9, "frames_per_clip": 999,
              "primary_timing_files": 648, "primary_summary_rows": 72, "profiles_including_separate_scipy": 80,
              "captured_matrices": matrix_count, "replay_summary_rows": 144, "replay_samples": replay_samples,
              "saved_objective_checks_including_alias": objective_checks, "recorded_nonzero_objective_gaps": 0,
              "recorded_alias_objective_differences": 0, "verified_saved_predictions": 72, "metric_formula_checks": 72,
              "input_observations": input_counts,
              "qualification": "Saved checks, counts, identities and arithmetic audited independently; no matrices solved, tracker run, detector invoked, or external absolute path opened. GT and RF pipelines were measured separately within one sequential session; ranges are descriptive extrema, not IQRs or significance intervals."}
    return report
if __name__ == "__main__":
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--collection",type=Path,default=Path(__file__).parent/"tracking-results")
    parser.add_argument("--output",type=Path,default=Path(__file__).parent/"tracking-audit.json")
    args=parser.parse_args()
    report=audit_evidence(args.collection)
    args.output.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report,indent=2))
