"""Untimed independent direct-API objective rechecks of the fresh replay corpus.

Run only after all campaign measurements finish. This does not import the
benchmark's dispatch or its objective helpers, and never modifies the corpus.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata as metadata
import json
import math
from pathlib import Path
import sys
import numpy as np
import scipy.optimize
import lap
import laprust
import lapcpp
from threadpoolctl import threadpool_limits

METHODS = ("lapjv", "lapjvx", "lapjvxa", "lapjvh", "laprust", "lapcpp",
           "scipy", "lapjvs", "lapjvc", "lapjvr")


def solve(name, a, precision):
    n, m = a.shape
    if name == "scipy":
        r, c = scipy.optimize.linear_sum_assignment(a)
    elif name == "lapjv":
        x, _ = lap.lapjv(a, extend_cost=n != m, cost_limit=np.inf, return_cost=False)
        r = np.flatnonzero(np.asarray(x) >= 0)
        c = np.asarray(x)[r]
    elif name == "lapjvx":
        r, c = lap.lapjvx(a, extend_cost=n != m, cost_limit=np.inf, return_cost=False)
    elif name == "lapjvxa":
        p = lap.lapjvxa(a, extend_cost=n != m, cost_limit=np.inf, return_cost=False)
        r, c = np.asarray(p).T
    elif name in ("lapjvh", "lapjvr", "laprust", "lapcpp"):
        fn = (laprust.lapjv if name == "laprust" else lapcpp.lapjv if name == "lapcpp"
              else getattr(lap, name))
        p = fn(a, extend_cost=n != m, cost_limit=np.inf, return_cost=False,
               precision="native", output="pairs")
        r, c = np.asarray(p).T
    elif name == "lapjvs":
        r, c = lap.lapjvs(a, extend_cost=n != m, return_cost=False, jvx_like=True,
                          prefer_float32=precision == "float32")
    else:
        r, c = lap.lapjvc(a, return_cost=False)
    r, c = np.asarray(r), np.asarray(c)
    assert r.shape == c.shape == (min(n, m),)
    assert set(r).issubset(range(n)) and set(c).issubset(range(m))
    assert len(set(r)) == len(r) and len(set(c)) == len(c)
    selected = a[r, c]
    return float(selected.sum(dtype=np.float64)), math.fsum(map(float, selected))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--collection", type=Path,
                        default=Path(__file__).parent / "tracking-results")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).parent / "tracking-resolve.json")
    args = parser.parse_args()
    root = args.collection.resolve()
    summary = json.loads((root / "summary.json").read_text())
    expected_versions = {"lapx": "0.13.0", "laprust": "1.2.0", "lapcpp": "1.2.0"}
    versions = {key: metadata.version(key) for key in
                ("numpy", "scipy", "lapx", "laprust", "lapcpp")}
    assert all(versions[k] == v for k, v in expected_versions.items())
    env = Path(sys.prefix).resolve()
    origins = {}
    for name, mod in (("lap", lap), ("laprust", laprust), ("lapcpp", lapcpp)):
        origin = Path(mod.__file__).resolve()
        assert origin.is_relative_to(env), origin
        origins[name] = "<tracking-env>/" + origin.relative_to(env).as_posix()
    records = []
    total = 0
    for case in sorted(summary["validation"]):
        capture = json.loads((root / "profiles" / f"{case}__scipy.json").read_text())
        with np.load(root / "matrices" / f"{case}.npz", allow_pickle=False) as store:
            originals = [store[row["key"]] for row in capture["matrix_metadata"]]
        for precision in ("float32", "float64"):
            outcomes = {method: {"method": method, "matrices": len(originals),
                                  "nonzero_gap_count": 0, "max_abs_gap": 0.,
                                  "fsum_nonzero_gap_count": 0, "fsum_max_abs_gap": 0.,
                                  "witnesses": []} for method in METHODS}
            for index, original in enumerate(originals):
                a = np.ascontiguousarray(original, dtype=precision)
                a.setflags(write=False)
                before = hashlib.sha256(a.tobytes()).digest()
                expected, fsum_expected = solve("scipy", a, precision)
                for method in METHODS:
                    actual, fsum_actual = solve(method, a, precision)
                    gap, fsum_gap = actual - expected, fsum_actual - fsum_expected
                    row = outcomes[method]
                    row["nonzero_gap_count"] += gap != 0
                    row["max_abs_gap"] = max(row["max_abs_gap"], abs(gap))
                    row["fsum_nonzero_gap_count"] += fsum_gap != 0
                    row["fsum_max_abs_gap"] = max(row["fsum_max_abs_gap"], abs(fsum_gap))
                    if (gap != 0 or fsum_gap != 0) and len(row["witnesses"]) < 20:
                        row["witnesses"].append({"matrix": index, "gap": gap,
                                                  "fsum_gap": fsum_gap})
                    total += 1
                assert hashlib.sha256(a.tobytes()).digest() == before
            records.append({"case": case, "precision": precision,
                            "methods": list(outcomes.values())})
            print(f"Rechecked {case} {precision}: {len(originals)} matrices", flush=True)
    no_gaps = all(row["nonzero_gap_count"] == row["fsum_nonzero_gap_count"] == 0
                  for group in records for row in group["methods"])
    report = {"status": "passed" if no_gaps else "objective_differences_recorded",
              "python": sys.version, "versions": versions, "origins": origins,
              "backend_matrix_checks": total, "records": records,
              "scope": "Untimed direct solver API re-solves, full cardinality and uniqueness checks;"
                       " objectives summed on represented costs in float64 and independently with math.fsum;"
                       " inputs read-only and byte hashes checked; required assignment only, no finite penalty."}
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "backend_matrix_checks": total}), flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=1):
        main()
